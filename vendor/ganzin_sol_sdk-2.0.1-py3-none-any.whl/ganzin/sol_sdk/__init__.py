""" Python SDK for interacting with servers powered by Ganzin Chronus. """

__version__ = "2.0.1"

# Minimum Ganzin Chronus *app* (user-facing release, i.e. the version users see
# in the store) this SDK build is compatible with -- NOT the server's API
# version. When the SDK is ahead of the server, the server reports only its API
# version, which the user cannot map to an installable release; so the target
# app version is shipped with the SDK binary here and surfaced in the upgrade
# hint. Bump this whenever a new SDK release requires a newer Chronus. See
# ganzin.sol_sdk.utils._validate_sdk_version.
__min_chronus_app_version__ = "2.2.1"

__all__ = [
    'synchronous',
    'asynchronous',
    'streaming',
    'requests',
    'responses',
    'common_models',
    'time_sync',
    'utils'
]