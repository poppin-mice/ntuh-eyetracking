from enum import Enum
import struct
from dataclasses import dataclass
from typing import List

from .media_type import MediaType
from .base_stream import BaseStream

class EventType(Enum):
    UNKNOWN = 0
    FIXATION = 1
    SACCADE = 2
    NOISE = 3

@dataclass
class Event:
    """Represents a single Event structure."""
    event_type_int: int
    """ @private """

    count: int
    """
    The index (sequential number) of the event within its specific eye movement event category.
    """

    onset_timestamp_us: int
    """
    The timestamp (in microseconds) when the eye movement event began.
    """

    offset_timestamp_us: int
    """
    The timestamp (in microseconds) when the eye movement event ended.
    """

    duration_us: int
    """
    The duration (in microseconds) of the eye movement event.
    """

    onset_position_x: float
    """
    For Fixation events: Represents the average horizontal coordinate of the
    gaze points included in the fixation event on the scene camera image.
    For Saccade events: Represents the horizontal coordinate of the gaze point
    on the scene camera image when the event began (onset).
    """

    onset_position_y: float
    """
    For Fixation events: Represents the average vertical coordinate of the
    gaze points included in the fixation event on the scene camera image.
    For Saccade events: Represents the vertical coordinate of the gaze point
    on the scene camera image when the event began (onset).
    """

    offset_position_x: float
    """
    For Fixation events: Represents the average horizontal coordinate of the
    gaze points included in the fixation event on the scene camera image.
    For Saccade events: Represents the horizontal coordinate of the gaze point
    on the scene camera image when the event ended (offset).
    """

    offset_position_y: float
    """
    For Fixation events: Represents the average vertical coordinate of the
    gaze points included in the fixation event on the scene camera image.
    For Saccade events: Represents the vertical coordinate of the gaze points
    on the scene camera image when the event ended (offset).
    """

    amplitude: float
    """
    For Saccade events: Represents the distance on the scene camera image between
    the gaze point at the start of the event (onset) and the gaze point at
    the end of the event (offset).
    """

    @property
    def event_type(self) -> EventType:
        """
        The category of the eye movement event, which may be Fixation, Saccade, or Unknown.
        """
        try:
            return EventType(self.event_type_int)
        except ValueError:
            return f"UNKNOWN_{self.event_type_int}"

    def __str__(self):
        return (
            f"Event("
            f"event_type={self.event_type.name},"
            f"count={self.count},"
            f"onset_timestamp_us={self.onset_timestamp_us},"
            f"offset_timestamp_us={self.offset_timestamp_us},"
            f"duration_us={self.duration_us},"
            f"onset_position_x={self.onset_position_x},"
            f"onset_position_y={self.onset_position_y},"
            f"offset_position_x={self.offset_position_x},"
            f"offset_position_y={self.offset_position_y},"
            f"amplitude={self.amplitude}"
            f")"
        )

@dataclass
class RealtimeResult:
    """Represents the main RealtimeResult structure."""
    packet_type: int
    """
    A reserved field (placeholder); the value is currently always set to 0.
    """

    is_fixation_int: int
    """ @private """

    fix_duration_us: int
    """
    The accumulated duration (in microseconds) of the current or most recent
    Fixation event up to the current timestamp.
    """

    flow_vel_x: float
    """
    The horizontal component of the angular velocity (in degrees per second)
    calculated using Optical Flow (a computer vision technique for
    motion estimation).
    """

    flow_vel_y: float
    """
    The vertical component of the angular velocity (in degrees per second)
    calculated using Optical Flow (a computer vision technique for
    motion estimation).
    """

    complete_events_count: int
    """
    The number of events (Fixation, Saccade, etc.) confirmed as fully classified
    and completed.
    """

    events: List[Event]
    """
    The data records for the events that have been confirmed as fully classified
    and completed.
    """

    timestamp_ms: int
    """
    Unix timestamp of the gaze event data in milliseconds, representing the
    total number of milliseconds elapsed since 00:00:00 UTC on January 1, 1970.
    """

    @property
    def is_fixation(self) -> bool:
        """
        Indicates whether the current gaze behavior is part of a Fixation event.
        """
        return True if self.is_fixation_int == 1 else False

    def get_timestamp_ms(self):
        """
        Returns the Unix timestamp of the gaze event data in milliseconds,
        representing the total number of milliseconds elapsed since
        00:00:00 UTC on January 1, 1970.
        """
        return self.timestamp_ms

    def __str__(self):
        # Generate the string representation for all events
        # Use a list comprehension to call str() on every Event object
        event_lines = [str(event) for event in self.events]

        # Join the list of event strings, adding indentation and a newline
        events_detail = "\n  ".join(event_lines) if self.complete_events_count > 0 else ""

        # If events exist, prepend a newline and indentation to format the list structure.
        if events_detail != "":
            events_detail = "\n  " + events_detail

        return (
            f"RealtimeResult(packet_type={self.packet_type},"
            f"is_fixation={self.is_fixation},"
            f"fix_duration_us={self.fix_duration_us:,}us,"
            f"flow_vel_x={self.flow_vel_x:.3f},"
            f"flow_vel_y={self.flow_vel_y:.3f},"
            f"complete_events_count={self.complete_events_count},"
            f"timestamp_ms={self.timestamp_ms},"
            f"events=[{events_detail}])"
        )

# Header format (Network Byte Order, No Padding): B B q d d B
HEADER_FORMAT = '!BBqddB'
""" @private """

HEADER_SIZE = struct.calcsize(HEADER_FORMAT)
""" @private """

# Event format (Network Byte Order, No Padding): B i q q q d d d d d
EVENT_FORMAT = '!Biqqqddddd'
""" @private """

EVENT_SIZE = struct.calcsize(EVENT_FORMAT)
""" @private """

class GazeEventStream(BaseStream):
    """
    Class for handling gaze event data from the RTSP stream.
    """
    def __init__(self, *args, **kwargs):
        self._requested_media = MediaType.OTHER
        super().__init__(*args, **kwargs, media_types={ 0: "application" })

    def handle_raw_data(self, packet, timestamp_ms, track_id):
        """
        @private

        Parses a single raw binary packet from the stream into a structured
        RealtimeResult object.

        This method unpacks the fixed header, uses the 'complete_events_count'
        to determine the number of subsequent Event structures, and then
        iteratively unpacks those events. It yields a single RealtimeResult
        instance containing all the parsed data.

        Arguments:
        ----------
            - packet: The raw binary packet containing the gaze event data.
            - timestamp_ms: The Unix timestamp (in milliseconds) associated with the packet.
            - track_id: The stream identifier for the data.

        Yields:
        -------
            RealtimeResult: A structured object encapsulating a snapshot of gaze event data.

        Raises:
        -------
            ValueError: If the packet data is incomplete or corrupted, or if
                        the expected number of bytes for the header or an
                        Event structure is not found.
        """
        if len(packet.data) < HEADER_SIZE:
            raise ValueError("Data too short to contain the fixed RealtimeResult header.")

        header_values = struct.unpack(HEADER_FORMAT, packet.data[:HEADER_SIZE])

        complete_events_count = header_values[-1]
        events: List[Event] = []
        current_offset = HEADER_SIZE

        # Iteratively Unpack the Events
        for i in range(complete_events_count):
            start = current_offset
            end = current_offset + EVENT_SIZE

            if len(packet.data) < end:
                raise ValueError(
                    f"Incomplete data. Header requested {complete_events_count} events, but ran out of data at event {i+1}."
                )

            # Unpack the event values
            event_values = struct.unpack(EVENT_FORMAT, packet.data[start:end])

            # Instantiate the Event dataclass directly from unpacked values
            events.append(Event(*event_values))

            current_offset = end

        yield RealtimeResult(*header_values, events=events, timestamp_ms=timestamp_ms)
