import asyncio
from dataclasses import dataclass
from dpkt.rtp import RTP
from functools import partial
from struct import unpack
from time import time
import traceback

from aiortsp.rtsp.errors import RTSPError
from aiortsp.transport.tcp import TCPTransport
from aiortsp.rtcp.parser import RTCP, SR, RTCP_TYPES
from aiortsp.rtcp.stats import RTCPStats
from aiortsp.rtsp.parser import RTSPBinary


# RFC 868 / RFC 5905 §6: number of seconds between the NTP prime epoch
# (1900-01-01 00:00:00 UTC) and the Unix epoch (1970-01-01 00:00:00 UTC),
# expressed in milliseconds.
_NTP_TO_UNIX_OFFSET_MS = 2_208_988_800_000

# An NTP fractional-seconds field (RFC 5905 §6) is the lower 32 bits of a
# 64-bit fixed-point number representing fractions of one second.
_NTP_FRACTION_DIVISOR = 1 << 32


def _ntp_fixed_to_unix_ms(seconds_since_1900: int, fraction: int) -> float:
    """
    Convert an RFC 3550 NTP timestamp (split into integer seconds and a
    32-bit fractional component) into milliseconds since the Unix epoch.
    """
    fractional_seconds = fraction / _NTP_FRACTION_DIVISOR
    millis_since_1900 = (seconds_since_1900 + fractional_seconds) * 1000.0
    return millis_since_1900 - _NTP_TO_UNIX_OFFSET_MS


def _decode_sender_report(header_byte: int, payload: bytes) -> 'SR':
    """
    Decode the body of an RTCP Sender Report (RFC 3550 §6.4.1).

    The first 24 bytes carry the sender info block::

        SSRC                    (u32)
        NTP timestamp MSW       (u32)  -- seconds since 1900-01-01
        NTP timestamp LSW       (u32)  -- fractional seconds
        RTP timestamp           (u32)
        sender's packet count   (u32)
        sender's octet count    (u32)

    Any remaining bytes are zero or more 24-byte report blocks, decoded by
    delegating to `SR.parse_reports` on the upstream class. The
    NTP sender timestamp is converted to milliseconds since the Unix
    epoch before being stored on the returned `SR` instance.
    """
    sender_info = payload[:24]
    (
        ssrc,
        ntp_seconds,
        ntp_fraction,
        rtp_timestamp,
        sender_packet_count,
        sender_octet_count,
    ) = unpack('!IIIIII', sender_info)

    ntp_unix_ms = _ntp_fixed_to_unix_ms(ntp_seconds, ntp_fraction)
    report_blocks = SR.parse_reports(header_byte, payload[24:])

    return SR(
        ssrc=ssrc,
        ntp=ntp_unix_ms,
        ts=rtp_timestamp,
        pkt_count=sender_packet_count,
        byte_count=sender_octet_count,
        reports=report_blocks,
    )


def _decode_compound_rtcp(buffer: bytes) -> 'RTCP':
    """
    Walk a compound RTCP buffer (RFC 3550 §6.4) and decode each contained
    packet.

    Every RTCP packet begins with a four-byte fixed header::

        bits  0-1 : version (must be 2)
        bit   2   : padding flag
        bits  3-7 : item count (interpretation depends on packet type)
        bits  8-15: packet type
        bits 16-31: length, in 32-bit words minus one, *excluding* the
                    header itself

    The total size of one packet, in bytes, is therefore
    `(length + 1) * 4`.

    For Sender Report packets this routine performs the SDK-specific
    NTP-to-Unix-millisecond conversion via `_decode_sender_report`;
    for every other packet type it delegates to the per-type `unpack`
    factory exposed by `aiortsp.rtcp.parser.RTCP_TYPES`.
    """
    decoded = []
    cursor = 0
    end = len(buffer)

    while cursor < end:
        header_byte, packet_type, length_in_words_minus_one = unpack(
            '!BBH', buffer[cursor:cursor + 4],
        )

        version = (header_byte >> 6) & 0x03
        if version != 2:
            raise ValueError(f'unsupported RTCP version: {version}')

        if packet_type not in RTCP_TYPES:
            raise ValueError(f'unknown RTCP packet type: {packet_type}')

        packet_size = (length_in_words_minus_one + 1) * 4
        if cursor + packet_size > end:
            raise ValueError(
                f'RTCP packet truncated: need {packet_size} bytes from '
                f'offset {cursor}, only {end - cursor} available'
            )

        payload = buffer[cursor + 4:cursor + packet_size]
        if header_byte & 0x20:
            pad_octets = payload[-1]
            payload = payload[:len(payload) - pad_octets]

        packet_cls = RTCP_TYPES[packet_type]
        if packet_cls is SR:
            decoded.append(_decode_sender_report(header_byte, payload))
        else:
            decoded.append(packet_cls.unpack(
                header_byte, packet_type, length_in_words_minus_one, payload,
            ))

        cursor += packet_size

    return RTCP(packets=decoded)

@dataclass
class _ChannelPair:
    """Interleaved RTP / RTCP channel indices owned by a single media track."""
    rtp_idx: int
    rtcp_idx: int


class CustomTCPTransport(TCPTransport):
    """
    Interleaved-TCP transport extended for multi-track presentations.

    The upstream transport assumes a single media track per connection.
    This subclass replaces that assumption with track-indexed state:
    each requested track owns its own pair of interleaved channels, its
    own `RTCPStats` accumulator, and its own RTCP and timeout
    supervisory tasks.
    """

    def __init__(self, *args, **kwargs):
        # The trailing positional argument is the track count (an
        # extension of the upstream signature); everything before it is
        # forwarded to the parent transport unchanged.
        *forwarded, track_count = args
        try:
            super().__init__(*forwarded, **kwargs)
            self.track_number = track_count
            self.channel_mappings: list = []
            self.interleaved_stats = [RTCPStats(i) for i in range(track_count)]
            self._rtcp_loops: list = [None] * track_count
            self._timeout_loops: list = [None] * track_count
        except Exception as ex:
            print(f"Error occur: {ex}")

    # ----- per-track interleaved channel registration --------------------

    async def prepare(self):
        register = self.connection.register_binary_handler
        for track_id in range(self.track_number):
            rtp_channel = register(partial(self.handle_rtp_bin, track_id=track_id))
            rtcp_channel = register(partial(self.handle_rtcp_bin, track_id=track_id))
            self.channel_mappings.append(_ChannelPair(rtp_channel, rtcp_channel))

            self.logger.info(
                'track %d bound to interleaved channels rtp=%d rtcp=%d',
                track_id, rtp_channel, rtcp_channel,
            )

    # ----- interleaved framing dispatch ----------------------------------

    def handle_rtcp_bin(self, binary: RTSPBinary, track_id):
        self.handle_rtcp_data(binary.data, track_id)

    def handle_rtp_bin(self, binary: RTSPBinary, track_id):
        self.handle_rtp_data(binary.data, track_id)

    # ----- SETUP negotiation ---------------------------------------------

    def on_transport_request(self, headers: dict, track_id):
        channels = self.channel_mappings[track_id]
        headers['Transport'] = ';'.join((
            'RTP/AVP/TCP',
            'unicast',
            f'interleaved={channels.rtp_idx}-{channels.rtcp_idx}',
        ))

    def on_transport_response(self, headers: dict):
        if 'transport' not in headers:
            raise RTSPError('SETUP response missing Transport header')
        # Server-side interleave validation is intentionally relaxed for
        # this transport; some peers echo a slightly different channel
        # range than the one we requested.

    # ----- per-track packet ingestion ------------------------------------

    async def send_rtcp_report(self, rtcp: RTCP, track_id):
        channels = self.channel_mappings[track_id]
        self.connection.send_binary(channels.rtcp_idx, bytes(rtcp))

    def handle_rtcp_data(self, data: bytes, track_id):
        """
        Decode an interleaved RTCP buffer with millisecond NTP timestamps
        and fan it out to subscribers. The remote server does not consume
        periodic RTCP from this client, so the per-track `rtcp_loop` is
        deliberately not started on first packet.
        """
        report = _decode_compound_rtcp(data)
        self.logger.debug('RTCP in (track=%d): %s', track_id, report)
        self.interleaved_stats[track_id].handle_rtcp(report)
        self._dispatch_to_clients(lambda c: c.handle_rtcp(report, track_id), 'RTCP')

    def handle_rtp_data(self, data: bytes, track_id):
        """
        Decode an interleaved RTP buffer, update per-track statistics
        and fan it out to subscribers.
        """
        packet = RTP(data)
        self.interleaved_stats[track_id].update(packet)
        self._dispatch_to_clients(lambda c: c.handle_rtp(packet, track_id), 'RTP')

    def _dispatch_to_clients(self, action, label: str):
        """
        Invoke `action(client)` for every registered client, logging
        any per-client failure under the supplied label.
        """
        for client in self.clients:
            try:
                action(client)
            except Exception as ex:
                self.logger.error('client %s callback raised: %r', label, ex)

    # ----- per-track supervisory tasks -----------------------------------

    async def rtcp_loop(self, track_id):
        """
        Periodically build and ship an RTCP report for one track,
        spacing each iteration by the interval reported by
        `RTCPStats`.
        """
        stats = self.interleaved_stats[track_id]
        first_iteration = True

        while self.running:
            interval = stats.rtcp_interval(first_iteration)
            first_iteration = False
            self.logger.debug('RTCP cadence (track=%d): %.3fs', track_id, interval)
            await asyncio.sleep(interval)

            report = self._safely_build_rtcp(track_id)
            if report is None:
                continue

            if not await self._safely_send_rtcp(report, track_id):
                continue

    def _safely_build_rtcp(self, track_id):
        stats = self.interleaved_stats[track_id]
        try:
            report = stats.build_rtcp()
        except Exception as ex:
            self.logger.error('RTCP build failed (track=%d): %r', track_id, ex)
            traceback.print_exc()
            return None
        if not report:
            self.logger.warning(
                'RTCP build produced nothing for track %d; still warming up?',
                track_id,
            )
            return None
        return report

    async def _safely_send_rtcp(self, report, track_id) -> bool:
        try:
            self.logger.debug('RTCP out (track=%d): %s', track_id, report)
            await self.send_rtcp_report(report, track_id)
            return True
        except asyncio.CancelledError:
            raise
        except Exception as ex:
            self.logger.error('RTCP send failed (track=%d): %r', track_id, ex)
            return False

    async def timeout_loop(self, track_id):
        """
        Close the transport if no RTP arrives for the configured timeout.
        Each iteration computes how long it must still wait based on the
        wall-clock distance to the next deadline, so a packet arriving
        mid-wait simply pushes the next iteration further out.
        """
        stats = self.interleaved_stats[track_id]
        ceiling = self.timeout

        while self.running:
            idle = time() - stats.last_received
            wait_for = max(ceiling - idle, 1)
            await asyncio.sleep(wait_for)

            if self.paused:
                continue

            idle = time() - stats.last_received
            if idle <= ceiling:
                # Data arrived during the wait — re-evaluate next iteration
                # instead of tripping the timeout now.
                continue

            self.logger.error(
                'track %d silent for %.1fs (limit %ds); closing transport',
                track_id, idle, ceiling,
            )
            return self.close(TimeoutError('no data'))

    # ----- shutdown -------------------------------------------------------

    def close(self, error=None):
        """
        Resolve the result future, cancel every per-track supervisory
        task, notify clients, and close the underlying RTSP control
        connection so error paths that bypass the surrounding context
        manager do not leak the socket.
        """
        if not self.result.done():
            if error is not None:
                self.result.set_exception(error)
            else:
                self.result.set_result(False)

        self._cancel_pending(self._rtcp_loops)
        self._cancel_pending(self._timeout_loops)
        self._dispatch_to_clients(lambda c: c.handle_closed(error), 'close')
        self.connection.close()

    @staticmethod
    def _cancel_pending(task_slots):
        """Cancel every non-finished task in `task_slots` and empty the list."""
        for task in list(task_slots):
            if task is not None and not task.done():
                task.cancel()
        task_slots.clear()

    async def warmup(self, track_id):
        """
        Spawn the per-track timeout watcher just before play begins.
        """
        if self.timeout:
            self._timeout_loops[track_id] = asyncio.ensure_future(
                self.timeout_loop(track_id)
            )
