import asyncio
from urllib.parse import urlparse

from aiortsp.rtsp.reader import RTSPReader
from aiortsp.rtsp.session import sanitize_rtsp_url
from dpkt.rtp import RTP

from .media_type import MediaType
from .custom_rtsp_connection import CustomRTSPConnection
from .custom_rtsp_media_session import CustomRTSPMediaSession
from .custom_tcp_transport import CustomTCPTransport


class CustomRTSPReader(RTSPReader):
    """
    RTSP reader that drives connection, transport and per-track media
    sessions for the SDK's streaming layer.

    Compared to the base reader this class adds:

      * support for the `rtspt` URL scheme, which selects interleaved-TCP
        transport via `CustomTCPTransport`;
      * orchestration of multiple concurrent RTP tracks (audio, video and
        an "other" channel) under a single RTSP session, as described in
        RFC 2326 §13.1.
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.media_type = kwargs.get('media_type', 'video')

    def handle_rtp(self, rtp: RTP, track_id):
        """
        Enqueue every received RTP packet for the consumer iterator,
        regardless of payload type.
        """
        self.queue.put_nowait((rtp, track_id))

    def transport_for_scheme(self, scheme: str):
        """
        Map an RTSP URL scheme to its transport class.

        `rtspt` is handled here as interleaved TCP via
        `CustomTCPTransport`; every other scheme is delegated to
        the base reader's implementation.
        """
        if scheme == 'rtspt':
            return CustomTCPTransport
        return super().transport_for_scheme(scheme)

    async def run_stream(self):
        """
        Establish the RTSP session, set up each requested media track and
        keep the stream alive until cancellation.
        """
        sanitized = sanitize_rtsp_url(self.media_url)
        self.logger.info('opening RTSP source: %s', sanitized)
        parsed_url = urlparse(self.media_url)

        async with CustomRTSPConnection(
            parsed_url.hostname, parsed_url.port or 554,
            parsed_url.username, parsed_url.password,
            logger=self.logger, timeout=self.timeout,
        ) as conn:
            self.logger.info('RTSP control channel ready')

            transport_class = self.transport_for_scheme(parsed_url.scheme)
            track_count = self.count_media_track()
            async with transport_class(
                conn, track_count,
                logger=self.logger, timeout=self.timeout,
            ) as transport:
                sessions = self.create_requested_medias(conn, transport)
                if len(sessions) in (1, 2):
                    await self.manage_streams(conn, transport, sessions)
                else:
                    raise ValueError(f"Invalid number of sessions: {len(sessions)}")

    def count_media_track(self) -> int:
        """
        Return how many media tracks the caller asked the reader to open.
        """
        count = 0
        if self._requested_media & MediaType.AUDIO:
            count += 1
        if self._requested_media & MediaType.VIDEO:
            count += 1
        if self._requested_media & MediaType.OTHER:
            count += 1
        return count

    def create_requested_medias(self, conn, transport):
        """
        Construct a `CustomRTSPMediaSession` for each requested
        media track, bound to the supplied connection and transport.
        """
        sessions = []
        if self._requested_media & MediaType.AUDIO:
            sessions.append(CustomRTSPMediaSession(
                conn, self.media_url, transport=transport,
                media_type='audio', logger=self.logger,
            ))
        if self._requested_media & MediaType.VIDEO:
            sessions.append(CustomRTSPMediaSession(
                conn, self.media_url, transport=transport,
                media_type='video', logger=self.logger,
            ))
        if self._requested_media & MediaType.OTHER:
            sessions.append(CustomRTSPMediaSession(
                conn, self.media_url, transport=transport,
                logger=self.logger,
            ))
        return sessions

    async def _periodic_keepalive(self, session):
        """
        Refresh `session` on its declared keepalive cadence until cancelled.
        """
        cadence = max(1, session.session_keepalive)
        while True:
            await asyncio.sleep(cadence)
            await session.keep_alive()

    async def _await_transport_end(self, conn, transport):
        """
        Block until either the RTSP connection or the transport stops running.
        """
        while conn.running and transport.running:
            await asyncio.sleep(1)

    async def manage_streams(self, conn, transport, sessions):
        """
        Drive the OPTIONS / DESCRIBE / SETUP / PLAY lifecycle for the
        supplied sessions and run a supervised keepalive until either the
        connection or transport stops running.

        Per RFC 2326, every track within one presentation issues its own
        SETUP request but shares a single `Session` header value, so the
        server treats them as a single logical session.
        """
        try:
            primary_session = sessions[0]
            await primary_session.options_describe()
            await primary_session.setup(0)

            for track_id, session in enumerate(sessions[1:], start=1):
                session.session_id = primary_session.session_id
                await session.setup(
                    track_id,
                    primary_session.sdp,
                    primary_session.session_options,
                )

            self.on_ready(conn, transport, primary_session)
            await primary_session.play()

            keepalive_task = asyncio.create_task(
                self._periodic_keepalive(primary_session)
            )
            liveness_task = asyncio.create_task(
                self._await_transport_end(conn, transport)
            )
            try:
                done, pending = await asyncio.wait(
                    {keepalive_task, liveness_task},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                for task in pending:
                    task.cancel()
                for task in done:
                    task.result()
            except asyncio.CancelledError:
                keepalive_task.cancel()
                liveness_task.cancel()
                self.logger.info('stream supervisor cancelled; unwinding')
                raise
        finally:
            self.logger.info('releasing %d session(s)', len(sessions))
            for session in sessions:
                await session.teardown()
