from typing import Iterator, Optional, Type

from aiortsp.rtsp.parser import (
    RTSPParser,
    RTSPMessage,
    RTSPRequest,
    RTSPResponse,
    RTSPBinary,
)

CRLF = b'\r\n'


class CustomRTSPParser(RTSPParser):
    """
    Streaming RTSP framing parser used by the SDK.

    Bytes pushed into `parse` accumulate in an internal buffer until they
    form a recognizable RTSP framing prefix: a status line starting with
    `RTSP`, an interleaved binary frame starting with `$`, or a request
    method name from `RTSPRequest.CLIENT_REQUESTS`. Once a prefix is
    identified, the appropriate `RTSPMessage` subclass is constructed and
    fed bytes until it reports completion. Bytes that do not yet form a
    known prefix are retained for the next call, so the parser tolerates
    arbitrary chunk boundaries from the transport layer.
    """

    def parse(self, data: bytes) -> Iterator[RTSPMessage]:
        """
        Advance the framing state machine by `data` and yield each
        `RTSPMessage` that completes as a result.

        Bytes that do not yet form a known framing prefix are retained in
        the internal holding buffer for the next call.
        """
        if not data:
            return

        buffer = self._prev_data + data
        self._prev_data = b''

        while buffer:
            if self.pending_msg is None:
                # Empty CRLF separators between messages are skipped.
                if buffer.startswith(CRLF):
                    buffer = buffer[2:]
                    continue

                kind = self._classify(buffer)
                if kind is None:
                    # The leading bytes are either an incomplete or unknown
                    # prefix; hold them for a future call.
                    self._prev_data = buffer
                    return
                self.pending_msg = kind()

            buffer, finished = self.pending_msg.feed(buffer)
            if finished:
                yield self.pending_msg
                self.pending_msg = None

    @staticmethod
    def _classify(buffer: bytes) -> Optional[Type[RTSPMessage]]:
        """
        Inspect the leading bytes of `buffer` and return the message class
        that should consume them, or `None` if the bytes are an incomplete
        or unrecognized prefix.
        """
        if buffer.startswith(b'RTSP'):
            return RTSPResponse
        if buffer.startswith(b'$'):
            return RTSPBinary
        if buffer.startswith(RTSPRequest.CLIENT_REQUESTS):
            return RTSPRequest
        if any(method.startswith(buffer) for method in RTSPRequest.CLIENT_REQUESTS):
            return RTSPRequest
        return None
