import struct
from dataclasses import dataclass
from typing import Optional

SEI_NAL_TYPE = 6
SEI_USER_DATA_UNREGISTERED = 5


def remove_emulation_prevention(data: bytes) -> bytes:
    """
    Strip 0x03 emulation-prevention bytes from a NAL RBSP payload.

    H.264 inserts a 0x03 byte whenever the sequence 00 00 01 or 00 00 00
    would appear inside a NAL payload to prevent it being mistaken for a
    start code. This function removes those extra bytes before parsing.
    """
    out = bytearray()
    i = 0
    while i < len(data):
        # Pattern: 00 00 03 XX where XX <= 03 — drop the 03
        if (i + 2 < len(data)
                and data[i] == 0x00
                and data[i + 1] == 0x00
                and data[i + 2] == 0x03
                and (i + 3 >= len(data) or data[i + 3] <= 0x03)):
            out += b'\x00\x00'
            i += 3
        else:
            out.append(data[i])
            i += 1
    return bytes(out)


@dataclass
class SeiMessage:
    """
    A single SEI (Supplemental Enhancement Information) message parsed
    from an H.264 NAL unit of type 6.
    """
    payload_type: int
    """
    The SEI payload type as defined in ITU-T H.264 Annex D.
    Common values: 0 = buffering_period, 1 = pic_timing,
    4 = user_data_registered_itu_t_t35, 5 = user_data_unregistered.
    """

    payload: bytes
    """
    The raw payload bytes for this SEI message (after emulation-prevention
    byte removal).
    """

    @property
    def is_user_data_unregistered(self) -> bool:
        """True when payload_type is 5 (user_data_unregistered)."""
        return self.payload_type == SEI_USER_DATA_UNREGISTERED

    @property
    def uuid(self) -> Optional[bytes]:
        """
        The 16-byte UUID prefix of a user_data_unregistered message,
        or None if the message is a different type or the payload is too short.
        """
        if self.is_user_data_unregistered and len(self.payload) >= 16:
            return self.payload[:16]
        return None

    @property
    def user_data(self) -> Optional[bytes]:
        """
        The bytes following the UUID in a user_data_unregistered message,
        or None if the message is a different type or there is no data after the UUID.
        """
        if self.is_user_data_unregistered and len(self.payload) > 16:
            return self.payload[16:]
        return None


@dataclass
class GZSceneCamMetaV1:
    """
    Ganzin scene-camera per-frame exposure metadata carried in the H.264 SEI
    stream as a user_data_unregistered payload (type 5, UUID "GZSceneCamMetav1").

    One SEI NAL unit is emitted immediately before each coded slice. Frames
    produced before the auto-exposure controller stabilises may carry no SEI at
    all; callers must tolerate missing metadata.

    Spec reference: RtspOverWebSocket.md §6 — Scene camera H.264 SEI metadata.
    """

    UUID = b'GZSceneCamMetav1'
    """16-byte identifier for this payload schema."""

    _STRUCT = struct.Struct('>fqd')
    """big-endian: float32 | int64 | float64"""

    exposure_level_ratio: float
    """
    Smoothed output of the auto-exposure controller in the range [0, 1].
    0 = minimum, 1 = maximum exposure level.
    """

    exposure_time_ns: int
    """Sensor integration time for this frame, in nanoseconds."""

    sensitivity: float
    """Effective sensor sensitivity for this frame, ISO-equivalent."""

    @classmethod
    def try_parse(cls, msg: 'SeiMessage') -> 'Optional[GZSceneCamMetaV1]':
        """
        Attempt to decode *msg* as a GZSceneCamMetaV1 payload.

        Returns a populated instance when:
          - payload_type == 5 (user_data_unregistered)
          - the first 16 bytes of the payload match the UUID "GZSceneCamMetav1"
          - at least 20 bytes of data follow the UUID

        Returns None for any other SEI message — callers should treat an
        unrecognized UUID as "skip and continue" rather than an error, as a
        future schema revision will use a new UUID (per spec).
        """
        if not msg.is_user_data_unregistered:
            return None
        if msg.uuid != cls.UUID:
            return None
        data = msg.user_data
        if data is None or len(data) < cls._STRUCT.size:
            return None
        ratio, time_ns, iso = cls._STRUCT.unpack(data[:cls._STRUCT.size])
        return cls(
            exposure_level_ratio=ratio,
            exposure_time_ns=time_ns,
            sensitivity=iso,
        )


def _read_sei_size(data: bytes, offset: int) -> tuple[int, int]:
    """
    Read an SEI extended-byte-encoded size field starting at *offset*.

    Each byte contributes 255 to the accumulated value until a byte
    less than 0xFF is found, which contributes its own value.

    Returns (value, new_offset).
    """
    value = 0
    while offset < len(data):
        byte = data[offset]
        offset += 1
        value += byte
        if byte != 0xFF:
            break
    return value, offset


def decode_sei_nal(nal_payload: bytes) -> list[SeiMessage]:
    """
    Decode all SEI messages from a raw H.264 NAL unit payload.

    Processing steps (per RtspOverWebSocket.md §6):
      1. Verify nal_unit_type == 6 (SEI).
      2. Apply emulation-prevention byte removal before parsing.
      3. Walk the payload list: each entry is payload_type (1–n B) | payload_size (1–n B) | data.
         payload_size is authoritative — unknown payloads are skipped using it,
         so a future UUID or unrecognized payload type never breaks parsing.

    *nal_payload* must start with the NAL header byte (the bytes as they arrive
    in the RTP packet, before any Annex-B start code is prepended).

    Returns an empty list if this is not a SEI NAL unit (type 6) or the payload
    is empty. Callers should pass each returned SeiMessage to
    GZSceneCamMetaV1.try_parse() and treat an unrecognized UUID as "skip and
    continue" rather than an error.
    """
    if not nal_payload:
        return []

    nal_header = nal_payload[0]
    nal_unit_type = nal_header & 0x1F

    if nal_unit_type != SEI_NAL_TYPE:
        return []

    # Strip the NAL header byte, then remove emulation-prevention bytes
    # before parsing the RBSP content (step 2).
    rbsp = remove_emulation_prevention(nal_payload[1:])

    messages = []
    offset = 0

    while offset < len(rbsp):
        # 0x80 is the RBSP trailing stop bit — end of SEI messages.
        if rbsp[offset] == 0x80:
            break

        # Steps 3: read type and size using the H.264 extended-byte encoding.
        payload_type, offset = _read_sei_size(rbsp, offset)
        payload_size, offset = _read_sei_size(rbsp, offset)

        # payload_size is authoritative: slice exactly that many bytes so that
        # unknown or vendor-specific payloads are skipped cleanly.
        payload = rbsp[offset: offset + payload_size]
        offset += payload_size

        messages.append(SeiMessage(payload_type=payload_type, payload=payload))

    return messages
