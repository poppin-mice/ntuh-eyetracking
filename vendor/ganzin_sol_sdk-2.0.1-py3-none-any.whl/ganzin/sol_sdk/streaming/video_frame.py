from dataclasses import dataclass, field
from typing import Optional

import av
import numpy

from .sei import GZSceneCamMetaV1


@dataclass
class VideoFrame:
    """
    Dataclass representing video frame data.
    """
    _frame: av.VideoFrame
    _timestamp_ms: float
    scene_cam_meta: Optional[GZSceneCamMetaV1] = field(default=None)
    """
    Per-frame scene-camera exposure metadata decoded from the H.264 SEI stream,
    or ``None`` when no ``GZSceneCamMetaV1`` SEI was attached to this frame.

    Example:
    --------
    ```python
    async for frame in recv_video(ac, Camera.SCENE):
        if frame.scene_cam_meta:
            print(frame.scene_cam_meta.exposure_level_ratio)
    ```
    """

    def get_buffer(self) -> numpy.ndarray[numpy.uint8]:
        """
        Returns the frame data as a numpy array.
        """
        return self._frame.to_ndarray(format="bgr24")

    def get_timestamp_ms(self):
        """
        Returns the Unix timestamp of the video frame data in milliseconds,
        representing the total number of milliseconds elapsed since
        00:00:00 UTC on January 1, 1970.
        """
        return self._timestamp_ms