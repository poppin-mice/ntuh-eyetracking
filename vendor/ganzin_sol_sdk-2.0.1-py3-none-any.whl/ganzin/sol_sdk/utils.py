import asyncio
import re
from threading import Thread
from typing import List, TypeVar
import weakref
import websockets
import time

from .common_models import SemanticVersion

T = TypeVar('T')

class TaskRunningThread(Thread):
    """
    A thread class that runs an asyncio task and supports cancellation.
    """

    def __init__(self, task, cancel_event: asyncio.Event):
        """
        Initializes the thread with the task and the cancel event.
        """
        super().__init__()
        self._task = task
        self._cancel_event = cancel_event

    def run(self):
        """
        Starts the asyncio event loop and runs the task.

        This method is called when the thread is started. It initializes the asyncio
        event loop and runs the provided task.
        """
        asyncio.run(self._thread_func(
            obj_ref = weakref.ref(self),
            task = self._task
        ))

    @staticmethod
    async def _thread_func(
        obj_ref: weakref.ReferenceType,
        task
    ):
        obj_ref()._loop = asyncio.get_event_loop()
        await task()
        obj_ref()._loop = None

    def cancel(self):
        """
        Cancels the running task by setting the cancel event.
        """
        if self._loop:
            self._loop.call_soon_threadsafe(self._set_cancel_event)

    def _set_cancel_event(self):
        self._cancel_event.set()

class UpdateListener:
    """
    A class that listens for updates from a WebSocket server.
    """
    def __init__(self, uri, callback):
        """
        Initializes the UpdateListener with the specified URI and
        callback function, which is called when an update is received.
        """
        self._uri = uri
        """ The URI of the WebSocket server to connect to. """
        self._callback = callback
        """ The callback function to handle the received messages. """

    async def begin_listen(self):
        """ Starts the listening task asynchronously. """
        self._update_task = asyncio.create_task(self.listen_func())

    async def end_listen(self):
        """  Cancels the listening task if it is running and waits for it to finish."""
        if self._update_task is not None:
            self._update_task.cancel()

            try:
                await self._update_task
            except asyncio.CancelledError:
                pass
            self._update_task = None
    
    async def listen_func(self):
        """
        The main listening function that connects to the WebSocket server
        and listens for updates.
        """
        async for msg in collect_update(self._uri):
            self._callback(msg)

async def collect_update(uri):
    """
    Asynchronously collect updates from a WebSocket server.
    """
    async for websocket in websockets.connect(uri):
        try:
            async for msg in websocket:
                yield msg
        except websockets.ConnectionClosed:
            print("Connection closed. Retry connect...")
            continue
        except asyncio.CancelledError:
            print("Task canceled")
            break

def get_timestamp_ms():
    """
    Returns the current timestamp in milliseconds.

    This function retrieves the current time in nanoseconds using `time.time_ns()`
    and converts it to milliseconds by dividing by 1,000,000.

    Returns
    -------
    int
        The current timestamp in milliseconds.
    """
    return time.time_ns() // 1_000_000

def find_nearest_timestamp_match(reference_timestamp_ms, data_list: List[T]) -> T:
    """
    Finds the data object in the list with the nearest timestamp to the reference timestamp.
    """
    nearest_match = min(data_list, key=lambda x: abs(x.get_timestamp_ms() - reference_timestamp_ms))
    return nearest_match

def _validate_sdk_version(api_version) -> bool:
    """
    Validates the SDK version against the specified API version.

    Parameters:
    ----------
    api_version : str
        The version of the API to validate against.

    Returns:
    -------
    bool
        True if the SDK version is compatible with the API version, False otherwise.

    Raises:
    -------
    Exception
        If the SDK version is outdated or newer in terms of major versions.

    This function retrieves the current SDK version of the "ganzin-sol-sdk" package
    and uses an internal validation function to check if it is compatible with the
    specified API version.

    Note on patch versions:
    -----------------------
    A patch-only delta is by definition compatible, so this function treats it
    as valid and stays silent regardless of which side is ahead. The rule keys
    on the *kind* of delta, not on who produced it.

    By project convention the Sol server does not bump the patch number: it
    changes only the major or minor version when its API changes, so in practice
    the patch component is owned by the SDK alone for SDK-side fixes that have no
    server-side counterpart. Warning the user about a patch mismatch would
    therefore be misleading -- when the SDK is older it would point at a server
    version that was never released (e.g. "update to 1.0.1" when the server only
    ships 1.0.0), and when the SDK is newer there is nothing for the user to do.

    The reverse-direction doctest below (SDK behind by a patch, server at 1.0.1)
    is a defensive case: should a server ever report a patch despite this
    convention, the compatibility-by-definition rule still applies and the SDK
    stays silent rather than raising.

    Note on the "SDK is ahead" hint:
    --------------------------------
    When the SDK is newer than the server, the user must upgrade the Ganzin
    Chronus app. The server reports only its API version, which does not map to
    an installable app version, so the target Chronus *app* (user-facing
    release) version is stored in ganzin.sol_sdk.__min_chronus_app_version__ --
    distinct from the API version -- and shipped with each SDK build. It is
    surfaced in the upgrade message as the exact minimum compatible version
    (deliberately not "or later": a much newer Chronus could carry a newer API
    major that this SDK does not support). Bump it whenever a new SDK release
    requires a newer Chronus.
    """
    from . import __version__, __min_chronus_app_version__
    return _validate_sdk_version_against(
        __version__, api_version, __min_chronus_app_version__
    )

def _validate_sdk_version_against(sdk_version, api_version, chronus_app_version=None) -> bool:
    '''
    ``chronus_app_version`` is the minimum Ganzin Chronus app (user-facing
    release) version this SDK is compatible with -- not the API version; when
    the SDK is ahead, it is named in the upgrade hint. When omitted, the hint
    degrades gracefully to the generic message.

    >>> _validate_sdk_version_against('1.0.0', '1.0.0')
    True
    >>> _validate_sdk_version_against('0.0.2', '1.0.0')
    Traceback (most recent call last):
    Exception: Your SDK version is outdated, please update to 1.0.0.
    >>> _validate_sdk_version_against('2.0.0', '1.0.0')
    Traceback (most recent call last):
    Exception: Your SDK version is newer, please update the Ganzin Chronus.
    >>> _validate_sdk_version_against('2.0.0', '1.0.0', '2.2.1')
    Traceback (most recent call last):
    Exception: Your SDK version is newer, please update the Ganzin Chronus to version 2.2.1.
    >>> _validate_sdk_version_against('1.1.0', '1.0.0')
    Warning: Your SDK version is newer in terms of minor versions, please update the Ganzin Chronus.
    False
    >>> _validate_sdk_version_against('1.1.0', '1.0.0', '2.2.1')
    Warning: Your SDK version is newer in terms of minor versions, please update the Ganzin Chronus to version 2.2.1.
    False
    >>> _validate_sdk_version_against('1.0.0', '1.1.0')
    Warning: Your SDK version is outdated in terms of minor versions, please update to 1.1.0.
    False
    >>> _validate_sdk_version_against('1.0.1', '1.0.0')  # SDK ahead by a patch (SDK-owned fix)
    True
    >>> _validate_sdk_version_against('1.0.0', '1.0.1')  # defensive: server-reported patch is still compatible
    True
    '''

    sdk_version = _parse_semantic_version(sdk_version)
    api_version = _parse_semantic_version(api_version)

    equal, is_sdk_newer, difference = _compare_semantic_version(sdk_version, api_version)
    if equal or difference == 'patch':
        return True
    else:
        if is_sdk_newer:
            head = '{}Your SDK version is newer{}, please update the Ganzin Chronus'
            if chronus_app_version:
                tail = ' to version {}.'.format(chronus_app_version)
            else:
                tail = '.'
            if difference == 'major':
                raise Exception(head.format('', '') + tail)
            elif difference == 'minor':
                print(head.format('Warning: ', ' in terms of minor versions') + tail)
                return False
        else:
            msg = '{}Your SDK version is outdated{}, please update to {}.'
            if difference == 'major':
                raise Exception(msg.format('', '', api_version))
            elif difference == 'minor':
                print(msg.format('Warning: ', ' in terms of minor versions', api_version))
                return False
            
def _parse_semantic_version(version):
    """
    Parse a semantic version string into a SemanticVersion object
    which contains major, minor, and patch versions.
    """
    pattern = r"^(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)$"
    match = re.match(pattern, version)
    if match:
        return SemanticVersion(
            major=int(match.group("major")),
            minor=int(match.group("minor")),
            patch=int(match.group("patch"))
        )
    else:
        raise ValueError(f"Invalid semantic version: {version}")
    
def _compare_semantic_version(v1: SemanticVersion, v2: SemanticVersion):
    '''
    Compare two semantic versions.

    Args:
        v1 (SemanticVersion): The first semantic version to compare.
        v2 (SemanticVersion): The second semantic version to compare.

    Returns:
        tuple: A tuple containing three elements:
            - bool: True if the versions are equal, False otherwise.
            - bool or None: If not equal, True if v1 is greater, False if v1 is lesser,
              None if versions are equal.
            - str or None: The part of the version that differs ('major', 'minor', 'patch'),
              or None if versions are equal.
    Raises:
        ValueError: If the comparison result of the two arguments is unexpected.
    '''
    if v1 == v2:
        return (True, None, None)
    else:
        if v1.major > v2.major:
            return (False, True, 'major')
        elif v1.major < v2.major:
            return (False, False, 'major')
        else:
            if v1.minor > v2.minor:
                return (False, True, 'minor')
            elif v1.minor < v2.minor:
                return (False, False, 'minor')
            else:
                if v1.patch > v2.patch:
                    return (False, True, 'patch')
                elif v1.patch < v2.patch:
                    return (False, False, 'patch')
                else:
                    raise ValueError(f"Invalid version comparison: {v1}, {v2}")

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)
