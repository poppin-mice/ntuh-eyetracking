import base64
from dataclasses import dataclass, fields
import json
from typing import Dict, List, Optional

from .common_models import ApiStatus, SceneCamExposureConfig
from .streaming.gaze_stream import GazeData, RawGazeData


def parse_json_to_object(json_data: str, cls: type) -> object:
    """
    Parses a JSON string and converts it into an instance of the specified class.

    Arguments:
    ----------
        - json_data (str): A JSON string representing the data.
        - cls (type): The class type to which the JSON data should be converted.

    Returns:
    --------
        object: An instance of the specified class populated with the JSON data.

    Example:
    --------
    ```python
    obj = parse_json_to_object(json_text, TagResponse)
    ```
    """
    data = json.loads(json_data)

    # Get the set of valid field names for the class
    valid_fields = {f.name for f in fields(cls)}

    # Filter out any unexpected fields
    filtered_data = {k: v for k, v in data.items() if k in valid_fields}

    return cls(**filtered_data)


def _build_dataclass_from_dict(cls, data, nested=None):
    """
    Best-effort dataclass construction from a server-provided dict.

    Filters out unexpected keys and tolerates missing optional fields (those
    with defaults). `nested` is an optional mapping `{key_name: nested_cls}`
    used to recursively convert nested dicts into nested dataclass instances.
    """
    if data is None:
        return None
    valid = {f.name for f in fields(cls)}
    nested = nested or {}
    kwargs = {}
    for k, v in data.items():
        if k not in valid:
            continue
        if k in nested and isinstance(v, dict):
            kwargs[k] = _build_dataclass_from_dict(nested[k], v)
        else:
            kwargs[k] = v
    return cls(**kwargs)


def _parse_envelope(
    data: dict,
    response_cls,
    result_cls=None,
    *,
    result_nested=None,
    status_converter=None,
):
    """
    General parser for the SOL HTTP response envelope `{status, message?, result?}`.

    Arguments:
        data:              the parsed JSON dict.
        response_cls:      the top-level dataclass that owns `status`, `message`,
                           and (optionally) `result`. Must accept these three
                           keyword arguments.
        result_cls:        the dataclass for the `result` payload, or `None`
                           for envelopes that carry no result (e.g.
                           `RecordResponse`, `LockResponse`).
        result_nested:     optional `{field_name: nested_dataclass}` map applied
                           recursively to dict-valued fields inside `result`.
        status_converter:  optional callable applied to `data['status']` — used
                           e.g. to convert the raw string into an `ApiStatus`
                           enum value.

    Missing or unexpected fields are tolerated: extra keys in the wire payload
    are dropped, and optional dataclass fields that were not transmitted
    receive their declared defaults.
    """
    raw_status = data['status']
    if status_converter is not None and not isinstance(raw_status, status_converter):
        status = status_converter(raw_status)
    else:
        status = raw_status

    kwargs = {'status': status, 'message': data.get('message')}

    # Only attach `result` when the response class actually declares the field,
    # so envelopes without a result (e.g. RecordResponse, LockResponse) still work.
    response_field_names = {f.name for f in fields(response_cls)}
    if 'result' in response_field_names:
        kwargs['result'] = (
            _build_dataclass_from_dict(result_cls, data.get('result'), result_nested)
            if result_cls is not None else None
        )

    return response_cls(**kwargs)


# =============================================================================
# /api/version
# =============================================================================

@dataclass
class VersionResult:
    """The payload returned inside `VersionResponse.result` for `/api/version`."""
    remote_api_version: str
    """ The SDK version supported by the server. """


@dataclass
class VersionResponse:
    """
    Represents the response from the version endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_version()
    print(resp.result.remote_api_version)
    ```
    """
    status: str
    """ The status of the response. """
    message: Optional[str] = None
    """ The optional human-readable message. """
    result: Optional[VersionResult] = None
    """ The version payload (present on success). """


def versionResponseMapper(data: dict) -> VersionResponse:
    """
    @private
    Build a VersionResponse from a parsed JSON dict.
    """
    return _parse_envelope(data, VersionResponse, VersionResult)


# =============================================================================
# /api/status
# =============================================================================

@dataclass
class PhoneStorageInfo:
    """
    Represents the storage information of the phone.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_status()
    print(resp.result.phone_storage_info.free_storage_byte)
    ```
    """
    free_storage_byte: int
    """ The amount of free storage in bytes. """
    total_storage_byte: int
    """ The total storage capacity in bytes. """


@dataclass
class PhoneStatusResult:
    """
    The payload returned inside `PhoneStatusResponse.result` for `/api/status`.

    All fields after `missing_data_rate` are newer additions and default to
    `None` / `False` if the server has not yet started sending them.
    """
    ip: Optional[str] = None
    """ The IP address of the device. """
    port: Optional[int] = None
    """ The port number of the device. """
    device_name: Optional[str] = None
    """ The name of the device. """
    device_battery_percentage: Optional[int] = None
    """ The battery percentage of the device. """
    is_screen_locked: Optional[bool] = None
    """ Indicates whether the screen is locked. """
    is_recording: Optional[bool] = None
    """ Indicates whether the device is currently recording. """
    recording_elapsed_time_us: Optional[int] = None
    """ The elapsed recording time in microseconds. """
    eye_image_encoding_enabled: Optional[bool] = None
    """ Indicates whether eye image encoding is enabled. """
    audio_enabled: Optional[bool] = None
    """ Indicates whether audio is enabled for the stream. """
    phone_storage_info: Optional[PhoneStorageInfo] = None
    """ The storage information of the phone. """
    is_foreground: Optional[bool] = None
    """ Indicates whether the app is running in foreground. """
    recording_start_time_us: Optional[int] = None
    """ The Unix timestamp in microseconds representing the start time of current recording. """
    missing_data_rate: Optional[float] = None
    """ Realtime statistics of how many ratio of eye data are invalid (0.0 ~ 1.0). """
    error_type: Optional[str] = None
    """
    The current error category reported by the device.
    One of 'DEVICE_DISCONNECTED', 'EYE_TRACKER_STOPPED', or None.
    """
    recording_folder_name: Optional[str] = None
    """ The folder name of the active recording, if any. """
    eye_image_streaming_enabled: bool = False
    """ Indicates whether the eye-image stream is enabled. """
    gaze_event_enabled: bool = False
    """ Indicates whether the gaze event stream is enabled. """


@dataclass
class PhoneStatusResponse:
    """
    Represents the response from the status endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_status()
    print(resp.result.device_name)
    ```
    """
    status: str
    """ The status of the response ('SUCCESS' or 'FAILED'). """
    message: Optional[str] = None
    """ The optional human-readable message. """
    result: Optional[PhoneStatusResult] = None
    """ The phone-status payload (present on success). """


def phoneStatusResponseMapper(data: dict) -> PhoneStatusResponse:
    """
    @private
    Build a PhoneStatusResponse from a parsed JSON dict.
    """
    return _parse_envelope(
        data, PhoneStatusResponse, PhoneStatusResult,
        result_nested={'phone_storage_info': PhoneStorageInfo},
    )


# =============================================================================
# /api/scene_camera_param
# =============================================================================

@dataclass
class CameraParam:
    """ Camera parameters for calibration and distortion correction. """

    intrinsic: list
    """
    The intrinsic camera matrix, which includes the focal length and optical center.
    It is a 3x3 matrix with the following structure:
    ```python
    [ fx  0  cx ]
    [ 0  fy  cy ]
    [ 0   0   1 ]
    ```
    where fx and fy are the focal lengths, and cx and cy are the coordinates of the optical center.
    """

    distort: list
    """
    The distortion coefficients for correcting lens distortion.
    It is a list of five elements:
    ```python
    [k1, k2, p1, p2, k3]
    ```
    where:
    - k1, k2, and k3 are the radial distortion coefficients.
    - p1 and p2 are the tangential distortion coefficients.
    """


@dataclass
class SceneCameraParamResult:
    """ Represents the result of the scene camera parameter retrieval endpoint. """
    camera_param: Optional[CameraParam] = None
    """ The camera parameters for the scene camera. """


@dataclass
class SceneCameraParamResponse:
    """
    Represents the response from the scene camera parameter endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_scene_camera_param()
    print(resp.result.camera_param.intrinsic)
    ```
    """

    status: ApiStatus
    """ The status of the response. """

    message: Optional[str] = None
    """ The message of the response. """

    result: Optional[SceneCameraParamResult] = None
    """ The retrieved scene camera parameters. """


def sceneCameraParamResponseMapper(data: dict) -> SceneCameraParamResponse:
    """
    @private
    Build a SceneCameraParamResponse from a parsed JSON dict.
    """
    return _parse_envelope(
        data, SceneCameraParamResponse, SceneCameraParamResult,
        result_nested={'camera_param': CameraParam},
        status_converter=ApiStatus,
    )


# =============================================================================
# /api/recording_start, /api/recording_stop, /api/lock, /api/unlock
# (envelope carries only {status, message?}; no result payload)
# =============================================================================

@dataclass
class RecordResponse:
    """
    Represents the response from the record endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.begin_record()
    print(resp.status)
    resp = sc.end_record()
    print(resp.status)
    ```
    """
    status: str
    message: Optional[str] = None


def recordResponseMapper(data: dict) -> RecordResponse:
    """
    @private
    Build a RecordResponse from a parsed JSON dict.
    """
    return _parse_envelope(data, RecordResponse)


@dataclass
class LockResponse:
    """
    Represents the response from the lock endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.lock()
    print(resp.status)
    resp = sc.unlock()
    print(resp.status)
    ```
    """
    status: str
    message: Optional[str] = None


def lockResponseMapper(data: dict) -> LockResponse:
    """
    @private
    Build a LockResponse from a parsed JSON dict.
    """
    return _parse_envelope(data, LockResponse)


# =============================================================================
# /api/post_scene_cam_exposure_config  (write-only; no result payload)
# =============================================================================

@dataclass
class PostSceneCamExposureConfigResponse:
    """
    Represents the response from `/api/post_scene_cam_exposure_config`.

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.post_scene_cam_exposure_config(req)
    print(resp.status)
    ```
    """
    status: str
    message: Optional[str] = None


def postSceneCamExposureConfigResponseMapper(data: dict) -> PostSceneCamExposureConfigResponse:
    """
    @private
    Build a PostSceneCamExposureConfigResponse from a parsed JSON dict.
    """
    return _parse_envelope(data, PostSceneCamExposureConfigResponse)


# =============================================================================
# /api/tag
# =============================================================================

@dataclass
class TagResult:
    """
    Represents the result of a tag request. The name and timestamp_us echo the request.
    """

    name: str
    timestamp_us: int


@dataclass
class TagResponse:
    """
    Represents the response from the tag endpoint.

    Example:
    ```python
    sc = SyncClient(address, port)
    color = TagColor.LightSeaGreen
    req = AddTagRequest('right moment', 'description', 1_000_000, color)
    resp = sc.add_tag(req)
    print(f'Add tag result? {resp}')
    ```
    """
    status: str
    message: Optional[str] = None
    result: Optional[TagResult] = None  # Contains a value only when tagging is successful.

    def __init__(self, status: str, message: Optional[str] = None, result: Optional[Dict] = None):
        self.status = status
        self.message = message
        if isinstance(result, dict):
            self.result = TagResult(**result)
        else:
            self.result = result


# =============================================================================
# /api/scene_cam_exposure_config  &  /api/post_scene_cam_exposure_config
# =============================================================================

@dataclass
class SceneCamExposureConfigResult:
    """The payload returned inside `SceneCamExposureConfigResponse.result`."""
    scene_cam_exposure_config: Optional[SceneCamExposureConfig] = None
    """ The current or updated scene-camera exposure configuration. """


@dataclass
class SceneCamExposureConfigResponse:
    """
    Represents the response from the scene-camera exposure config endpoints.

    Returned by both `get_scene_cam_exposure_config()` (read) and
    `post_scene_cam_exposure_config()` (write).

    Example:
    ```python
    sc = SyncClient(address, port)
    resp = sc.get_scene_cam_exposure_config()
    if resp.status == 'SUCCESS':
        cfg = resp.result.scene_cam_exposure_config
        print(cfg.mode, cfg.fixed_mode_level)
    ```
    """
    status: str
    """ The status of the response ('SUCCESS' or 'FAILED'). """
    message: Optional[str] = None
    """ Human-readable detail, present when status is 'FAILED'. """
    result: Optional[SceneCamExposureConfigResult] = None
    """ The exposure configuration payload (present on success). """


def sceneCamExposureConfigResponseMapper(data: dict) -> SceneCamExposureConfigResponse:
    """
    @private
    Build a SceneCamExposureConfigResponse from a parsed JSON dict.
    """
    return _parse_envelope(
        data, SceneCamExposureConfigResponse, SceneCamExposureConfigResult,
        result_nested={'scene_cam_exposure_config': SceneCamExposureConfig},
    )


# =============================================================================
# /api/capture_scene_with_gaze
# =============================================================================

# =============================================================================
# /api/snapshot
# =============================================================================

@dataclass
class RequestSnapshotResult:
    """The payload returned inside `RequestSnapshotResponse.result` for `/api/snapshot`."""
    timestamp_us: int
    """
    Scene presentation timestamp in microseconds for the queued snapshot.
    Pass this value to `/api/get_snapshot_image` and `/api/get_snapshot_gaze`.
    """


@dataclass
class RequestSnapshotResponse:
    """
    Represents the response from the snapshot endpoint.

    Example:
    ```python
    async with AsyncClient(address, port) as ac:
        resp = await ac.snapshot()
        if resp.status == 'SUCCESS':
            print(resp.result.timestamp_us)
    ```
    """
    status: str
    """ The status of the response ('SUCCESS' or 'FAILED'). """
    message: Optional[str] = None
    """ Human-readable detail, present when status is 'FAILED'. """
    result: Optional[RequestSnapshotResult] = None
    """ The snapshot payload (present on success). """


def requestSnapshotResponseMapper(data: dict) -> RequestSnapshotResponse:
    """
    @private
    Build a RequestSnapshotResponse from a parsed JSON dict.
    """
    return _parse_envelope(data, RequestSnapshotResponse, RequestSnapshotResult)


# =============================================================================
# /api/get_snapshot_image
# =============================================================================

@dataclass
class GetSnapshotImageResult:
    """
    The payload returned inside `GetSnapshotImageResponse.result`.

    `filepath` is the relative path returned by the server.
    `image_data` is populated by the client after downloading the file from
    `/api/file/{filepath}` and is not part of the JSON response.
    """
    filepath: Optional[str] = None
    """
    Relative path of the snapshot image on the device.
    Pass it as the path suffix of `/api/file` to download the actual image.
    """
    image_data: Optional[bytes] = None
    """
    Raw image bytes downloaded from `/api/file/{filepath}`.
    Populated by the client automatically after a successful filepath lookup.
    """


@dataclass
class GetSnapshotImageResponse:
    """
    Represents the response from the get_snapshot_image endpoint.

    The client automatically downloads the image file and attaches the raw
    bytes to `result.image_data` when `status` is 'SUCCESS'.

    Example:
    ```python
    async with AsyncClient(address, port) as ac:
        resp = await ac.get_snapshot_image(timestamp_us)
        if resp.status == 'SUCCESS':
            with open('snapshot.jpg', 'wb') as f:
                f.write(resp.result.image_data)
    ```
    """
    status: str
    """ The status of the response ('SUCCESS' or 'FAILED'). """
    message: Optional[str] = None
    """ Human-readable detail, present when status is 'FAILED'. """
    result: Optional[GetSnapshotImageResult] = None
    """ The image payload (present on success). """


def getSnapshotImageResponseMapper(data: dict) -> GetSnapshotImageResponse:
    """
    @private
    Build a GetSnapshotImageResponse from a parsed JSON dict.
    Note: result.image_data is NOT populated here; the client fills it in
    after downloading the file from /api/file.
    """
    return _parse_envelope(data, GetSnapshotImageResponse, GetSnapshotImageResult)


# =============================================================================
# /api/get_snapshot_gaze
# =============================================================================

@dataclass
class SnapshotGazeData:
    """
    Gaze sample returned by `/api/get_snapshot_gaze`.

    All fields are optional with None defaults so that the SDK remains
    compatible with future server versions that add or remove fields.

    Field naming follows the OpenAPI `GazeData` schema (snake_case).
    """
    timestamp_us: Optional[int] = None
    """ Timestamp of the gaze sample in microseconds. """
    gaze_valid: Optional[int] = None
    """ Validity flag for the combined scene-camera gaze (0 = invalid, 1 = valid). """
    gaze_pos_x: Optional[float] = None
    """ Gaze position x on the scene-camera image, in pixels. """
    gaze_pos_y: Optional[float] = None
    """ Gaze position y on the scene-camera image, in pixels. """
    left_pupil_size: Optional[float] = None
    """ Left eye pupil size. """
    right_pupil_size: Optional[float] = None
    """ Right eye pupil size. """
    left_eye_3d_gaze_valid: Optional[int] = None
    """ Validity flag for the left eye 3D gaze vector. """
    left_eye_3d_gaze_orig_x: Optional[float] = None
    """ Left eye gaze origin x in 3D space, mm. """
    left_eye_3d_gaze_orig_y: Optional[float] = None
    """ Left eye gaze origin y in 3D space, mm. """
    left_eye_3d_gaze_orig_z: Optional[float] = None
    """ Left eye gaze origin z in 3D space, mm. """
    left_eye_3d_gaze_dir_x: Optional[float] = None
    """ Left eye gaze direction x (unit vector). """
    left_eye_3d_gaze_dir_y: Optional[float] = None
    """ Left eye gaze direction y (unit vector). """
    left_eye_3d_gaze_dir_z: Optional[float] = None
    """ Left eye gaze direction z (unit vector). """
    right_eye_3d_gaze_valid: Optional[int] = None
    """ Validity flag for the right eye 3D gaze vector. """
    right_eye_3d_gaze_orig_x: Optional[float] = None
    """ Right eye gaze origin x in 3D space, mm. """
    right_eye_3d_gaze_orig_y: Optional[float] = None
    """ Right eye gaze origin y in 3D space, mm. """
    right_eye_3d_gaze_orig_z: Optional[float] = None
    """ Right eye gaze origin z in 3D space, mm. """
    right_eye_3d_gaze_dir_x: Optional[float] = None
    """ Right eye gaze direction x (unit vector). """
    right_eye_3d_gaze_dir_y: Optional[float] = None
    """ Right eye gaze direction y (unit vector). """
    right_eye_3d_gaze_dir_z: Optional[float] = None
    """ Right eye gaze direction z (unit vector). """
    combined_3d_gaze_valid: Optional[int] = None
    """ Validity flag for the combined 3D gaze position. """
    combined_3d_gaze_pos_x: Optional[float] = None
    """ Combined 3D gaze position x, mm. """
    combined_3d_gaze_pos_y: Optional[float] = None
    """ Combined 3D gaze position y, mm. """
    combined_3d_gaze_pos_z: Optional[float] = None
    """ Combined 3D gaze position z, mm. """
    left_blink_count: Optional[int] = None
    """ Cumulative left eye blink count. """
    right_blink_count: Optional[int] = None
    """ Cumulative right eye blink count. """


@dataclass
class GetSnapshotGazeResult:
    """The payload returned inside `GetSnapshotGazeResponse.result`."""
    gaze: Optional[SnapshotGazeData] = None
    """ The gaze sample closest to the requested snapshot timestamp. """


@dataclass
class GetSnapshotGazeResponse:
    """
    Represents the response from the get_snapshot_gaze endpoint.

    Example:
    ```python
    async with AsyncClient(address, port) as ac:
        from ganzin.sol_sdk.requests import GetSnapshotGazeRequest
        resp = await ac.get_snapshot_gaze(GetSnapshotGazeRequest(timestamp_us))
        if resp.status == 'SUCCESS' and resp.result.gaze:
            print(resp.result.gaze.gaze_pos_x, resp.result.gaze.gaze_pos_y)
    ```
    """
    status: str
    """ The status of the response ('SUCCESS' or 'FAILED'). """
    message: Optional[str] = None
    """ Human-readable detail, present when status is 'FAILED'. """
    result: Optional[GetSnapshotGazeResult] = None
    """ The gaze payload (present on success). """


def getSnapshotGazeResponseMapper(data: dict) -> GetSnapshotGazeResponse:
    """
    @private
    Build a GetSnapshotGazeResponse from a parsed JSON dict.
    """
    return _parse_envelope(
        data, GetSnapshotGazeResponse, GetSnapshotGazeResult,
        result_nested={'gaze': SnapshotGazeData},
    )


@dataclass
class CaptureRawResult:
    """
    @private
    Represents the raw result of a capture request.
    """
    timestamp_us: int
    """ Unix timestamp in microseconds. Represents the total number of microseconds elapsed since 00:00:00 UTC on January 1, 1970. """
    gazeData: RawGazeData
    """ The raw gaze data. """
    sceneImgBase64: Optional[str] = None
    """ The base64-encoded scene camera image (may be omitted by the server). """


@dataclass
class CaptureResponse:
    """
    Represents the response from the capture endpoint.
    Please use `CaptureResult` instead, since it makes gaze data more organized.
    """
    status: str
    """ The status of the response. """
    message: Optional[str] = None
    """ The message of the response. """
    result: Optional[CaptureRawResult] = None
    """ The raw result of the response. It contains the timestamp, scene camera image, and gaze data. """


def captureResponseMapper(data: dict) -> CaptureResponse:
    """
    @private
    Build a CaptureResponse from a parsed JSON dict.
    """
    return _parse_envelope(
        data, CaptureResponse, CaptureRawResult,
        result_nested={'gazeData': RawGazeData},
    )


@dataclass
class CaptureResult:
    """
    Represents the processed result of a capture request, containing the timestamp,
    scene camera image, and gaze data.

    Example:
    ----------------
    ```python
    sc = SyncClient(address, port)
    resp = sc.capture()
    result = CaptureResult.from_raw(resp.result)
    print(f'timestamp_us = {result.timestamp_us}')
    print(f'gaze: x = {result.gaze_data.combined.gaze_2d.x}, y = {result.gaze_data.combined.gaze_2d.y}')
    with open("image_captured.jpg", "wb") as file:
        file.write(result.scene_image)
        print(f'Saved image to "{file.name}"')
    ```
    """
    timestamp_us: int
    """ Unix timestamp in microseconds. Represents the total number of microseconds elapsed since 00:00:00 UTC on January 1, 1970. """
    scene_image: bytes
    """ The scene camera image data. """
    gaze_data: GazeData
    """ The gaze data. """

    @classmethod
    def from_raw(cls, source: CaptureRawResult):
        """ Creates a CaptureResult instance from the provided CaptureRawResult object. """
        image = base64.b64decode(source.sceneImgBase64) if source.sceneImgBase64 else b''
        gaze = GazeData.from_raw(source.gazeData, source.timestamp_us)
        return cls(source.timestamp_us, image, gaze)


@dataclass
class GetHostsResult:
    hosts: List[str]
    """ List of discovered host IP addresses returned by the mDNS discovery service. """


@dataclass
class GetHostsResponse:
    status: str
    message: Optional[str]
    result: Optional[GetHostsResult]


def getHostsResponseMapper(data: dict) -> GetHostsResponse:
    return _parse_envelope(data, GetHostsResponse, GetHostsResult)
