import asyncio
from http import HTTPStatus
import json
from typing import List, Union
import urllib3
import urllib3.util
import weakref

from ..common_models import ApiStatus, Camera
from .eye_camera_stream_collector import EyeCameraStreamCollector
from ..api import Api
from ..responses import (
    CaptureResponse, GetHostsResponse, LockResponse, PhoneStatusResponse, RecordResponse,
    TagResponse, VersionResponse, SceneCameraParamResponse,
    RequestSnapshotResponse, GetSnapshotImageResponse, GetSnapshotGazeResponse,
    SceneCamExposureConfigResponse, PostSceneCamExposureConfigResponse,
    getHostsResponseMapper, lockResponseMapper, recordResponseMapper, versionResponseMapper,
    captureResponseMapper, phoneStatusResponseMapper, sceneCameraParamResponseMapper,
    requestSnapshotResponseMapper, getSnapshotImageResponseMapper, getSnapshotGazeResponseMapper,
    sceneCamExposureConfigResponseMapper, postSceneCamExposureConfigResponseMapper,
    parse_json_to_object
)
from ..requests import AddTagRequest, GetSnapshotGazeRequest, PostSceneCamExposureConfigRequest
from ..utils import TaskRunningThread, UpdateListener, _validate_sdk_version
from .gaze_stream_collector import GazeStreamCollector
from .models import StreamingMode
from ..streaming.protocol import streaming_scheme
from ..streaming.gaze_stream import GazeData
from ..streaming.video_frame import VideoFrame
from ..streaming.audio_frame import AudioFrame
from ..streaming.gaze_event_stream import RealtimeResult
from .streaming_data_coordinator import StreamingDataCoordinator
from ..time_sync import TimeSync, TimeSyncResult
from .scene_camera_video_collector import SceneCameraVideoCollector
from .scene_camera_audio_collector import SceneCameraAudioCollector
from .scene_camera_av_collector import SceneCameraAvCollector
from .gaze_event_stream_collector import GazeEventStreamCollector


class SyncClient:
    """
    Synchronous client for interacting with the server.
    """
    def __init__(self, address, port, rtsp_port=8086):
        """
        Initializes the client with the specified address and port.

        Arguments:
        ----------
        - **address** : str
            The IP address of the server.
        - **port** : int
            The port number of the server.
        - **rtsp_port** : int, optional
            The RTSP port number of the server. Default is 8086.
        """
        self._uri = f"{address}:{port}"
        self._rtsp_uri = f"{streaming_scheme}://{address}:{rtsp_port}/?camera="
        timeout = urllib3.util.Timeout(connect=2.0, read=7.0)
        self._http = urllib3.PoolManager(timeout=timeout)
        self._data = StreamingDataCoordinator()
        version_resp = self.get_version()
        if version_resp.result is None:
            raise RuntimeError(
                f'/api/version did not return a result: {version_resp.message!r}'
            )
        _validate_sdk_version(version_resp.result.remote_api_version)

    def _get_uri(self, api: Api, protocol="http"):
        return f"{protocol}://{self._uri}/api/{api}"
    
    def get_version(self) -> VersionResponse:
        """
        Retrieves the SDK version that the server is expected to support.

        Returns:
        --------
            VersionResponse: The response object containing the SDK version.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_version()
        print(resp.result.remote_api_version)
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.GET_VERSION.value))
        return versionResponseMapper(json.loads(resp.data))

    def get_hosts(self) -> GetHostsResponse:
        """
        Returns discovered host addresses from the mDNS discovery service.

        Returns:
        --------
            GetHostsResponse: The response object containing the list of discovered host IPs.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_hosts()
        print(resp.result.hosts)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.GET_HOSTS.value))
        return getHostsResponseMapper(json.loads(resp.data))

    def get_status(self) -> PhoneStatusResponse:
        """
        Retrieves the status of the server.

        Returns:
        --------
            PhoneStatusResponse: The response object containing the status information.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_status()
        print(resp.result.device_name)
        ```
        """
        resp = self._http.request("GET", self._get_uri(Api.GET_STATUS.value))
        return phoneStatusResponseMapper(json.loads(resp.data))

    def get_scene_camera_param(self) -> SceneCameraParamResponse:
        """
        Retrieves the scene camera parameters.
        
        Returns:
        --------
            SceneCameraParamResponse: The response object containing the status, message, and optionally the scene camera parameters.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_scene_camera_param()
        print(resp.result.camera_param.intrinsic)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.GET_SCENE_CAMERA_PARAM.value))
        if resp.status == HTTPStatus.OK:
            return sceneCameraParamResponseMapper(json.loads(resp.data))
        else:
            data = resp.json()
            return SceneCameraParamResponse(ApiStatus(data["status"]), data.get("message"), None)

    def begin_record(self) -> RecordResponse:
        """
        Send a request to the server to initiate recording.

        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.begin_record()
        print(resp.status)
        resp = sc.end_record()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.BEGIN_RECORD.value))
        return recordResponseMapper(json.loads(resp.data))

    def end_record(self) -> RecordResponse:
        """
        Send a request to the server to stop recording.

        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.begin_record()
        print(resp.status)
        resp = sc.end_record()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.END_RECORD.value))
        return recordResponseMapper(json.loads(resp.data))
    
    def add_tag(self, request: AddTagRequest) -> TagResponse:
        """
        Send a request to the server to add the specified tag.

        Arguments:
        ----------
            request (AddTagRequest): The request object containing tag information.

        Returns:
        --------
            TagResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        status_resp = sc.get_status()
        elapsed_us = status_resp.result.recording_elapsed_time_us
        req = AddTagRequest('right moment', 'description', elapsed_us, TagColor.LightSeaGreen)
        resp = sc.add_tag(req)
        print(f'Add tag result: {resp}')
        ```
        """
        resp = self._http.request(
            "POST",
            self._get_uri(Api.ADD_TAG.value),
            json=request.to_json_body()
        )
        return parse_json_to_object(resp.data, TagResponse)

    def capture(self) -> CaptureResponse:
        """
        Request server to capture frame and gaze.

        The response includes the frame image and the gaze data at that moment.

        Returns:
        --------
            CaptureResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.capture()
        result = CaptureResult.from_raw(resp.result)
        print(f'timestamp_us = {result.timestamp_us}')
        print(f'gaze: x = {result.gaze_data.combined.gaze_2d.x}, y = {result.gaze_data.combined.gaze_2d.y}')
        with open("image_captured.jpg", "wb") as file:
            file.write(result.scene_image)
            print(f'Saved image to "{file.name}"') 
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.CAPTURE.value))
        return captureResponseMapper(json.loads(resp.data))
    
    def snapshot(self) -> RequestSnapshotResponse:
        """
        Queue a snapshot on the next scene-camera frame.

        On success, `result.timestamp_us` is the presentation timestamp in
        microseconds. Pass it to `get_snapshot_image` and `get_snapshot_gaze`
        to retrieve the captured image and gaze data.

        Returns `status='FAILED'` with `message='Not previewing'` when the
        camera pipeline is not running.

        Returns:
        --------
            RequestSnapshotResponse: Contains `result.timestamp_us` on success.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.snapshot()
        if resp.status == 'SUCCESS':
            print(f'Snapshot queued at {resp.result.timestamp_us} us')
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.SNAPSHOT.value))
        return requestSnapshotResponseMapper(json.loads(resp.data))

    def get_snapshot_image(self, timestamp_us: int) -> GetSnapshotImageResponse:
        """
        Retrieve the snapshot image for a given presentation timestamp.

        Internally makes two HTTP calls:
          1. POST `/api/get_snapshot_image?timestamp_us=<value>` to get the
             relative file path from the device.
          2. GET `/api/file/<filepath>` to download the raw image bytes.

        The raw bytes are attached to `result.image_data` before the response
        is returned, so callers can write them to disk directly.

        Arguments:
        ----------
            timestamp_us (int): Presentation timestamp in microseconds, as
                returned by `snapshot()`.

        Returns:
        --------
            GetSnapshotImageResponse: Contains `result.filepath` and
                `result.image_data` (bytes) on success.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_snapshot_image(timestamp_us)
        if resp.status == 'SUCCESS':
            with open('snapshot.jpg', 'wb') as f:
                f.write(resp.result.image_data)
            print(f'Saved to snapshot.jpg (from {resp.result.filepath})')
        ```
        """
        url = f"{self._get_uri(Api.GET_SNAPSHOT_IMAGE.value)}?timestamp_us={timestamp_us}"
        resp = self._http.request("POST", url)
        meta = getSnapshotImageResponseMapper(json.loads(resp.data))

        if meta.status == 'SUCCESS' and meta.result and meta.result.filepath:
            file_url = f"{self._get_uri(Api.FILE.value)}/{meta.result.filepath}"
            file_resp = self._http.request("GET", file_url)
            meta.result.image_data = file_resp.data

        return meta

    def get_snapshot_gaze(self, request: GetSnapshotGazeRequest) -> GetSnapshotGazeResponse:
        """
        Retrieve the gaze sample closest to a snapshot timestamp.

        Arguments:
        ----------
            request (GetSnapshotGazeRequest): Contains `timestamp_us` in
                microseconds, matching the value returned by `snapshot()`.

        Returns:
        --------
            GetSnapshotGazeResponse: Contains `result.gaze` (a
                `SnapshotGazeData` instance) on success.

        Example:
        --------
        ```python
        from ganzin.sol_sdk.requests import GetSnapshotGazeRequest
        sc = SyncClient(address, port)
        resp = sc.get_snapshot_gaze(GetSnapshotGazeRequest(timestamp_us))
        if resp.status == 'SUCCESS' and resp.result.gaze:
            g = resp.result.gaze
            print(f'Gaze: ({g.gaze_pos_x:.1f}, {g.gaze_pos_y:.1f})  valid={g.gaze_valid}')
        ```
        """
        resp = self._http.request(
            "POST",
            self._get_uri(Api.GET_SNAPSHOT_GAZE.value),
            json=request.to_json_body()
        )
        return getSnapshotGazeResponseMapper(json.loads(resp.data))

    def get_scene_cam_exposure_config(self) -> SceneCamExposureConfigResponse:
        """
        Retrieve the current scene-camera exposure configuration.

        Returns:
        --------
            SceneCamExposureConfigResponse: Contains `result.scene_cam_exposure_config`
                (a `SceneCamExposureConfig` instance) on success.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.get_scene_cam_exposure_config()
        if resp.status == 'SUCCESS':
            cfg = resp.result.scene_cam_exposure_config
            print(f'Mode: {cfg.mode}, Level: {cfg.fixed_mode_level}')
        ```
        """
        resp = self._http.request(
            "POST", self._get_uri(Api.GET_SCENE_CAM_EXPOSURE_CONFIG.value)
        )
        return sceneCamExposureConfigResponseMapper(json.loads(resp.data))

    def post_scene_cam_exposure_config(
        self, request: PostSceneCamExposureConfigRequest
    ) -> PostSceneCamExposureConfigResponse:
        """
        Update the scene-camera exposure configuration.

        Only the fields set on `request.scene_cam_exposure_config` are sent;
        `None` fields are omitted so unrelated settings are left unchanged.

        Arguments:
        ----------
            request (PostSceneCamExposureConfigRequest): The new exposure
                configuration to apply.

        Returns:
        --------
            PostSceneCamExposureConfigResponse: Contains `status` and an optional
                `message` on failure.

        Example:
        --------
        ```python
        from ganzin.sol_sdk.common_models import SceneCamExposureConfig, SceneCamExposureMode
        from ganzin.sol_sdk.requests import PostSceneCamExposureConfigRequest

        sc = SyncClient(address, port)
        req = PostSceneCamExposureConfigRequest(
            SceneCamExposureConfig(mode=SceneCamExposureMode.FIXED, fixed_mode_level=0.7)
        )
        resp = sc.post_scene_cam_exposure_config(req)
        if resp.status == 'SUCCESS':
            print('Config updated successfully')
        ```
        """
        resp = self._http.request(
            "POST",
            self._get_uri(Api.POST_SCENE_CAM_EXPOSURE_CONFIG.value),
            json=request.to_json_body()
        )
        return postSceneCamExposureConfigResponseMapper(json.loads(resp.data))

    def lock(self) -> LockResponse:
        """
        Send a request to the server to switch the "Ganzin Chronus" app to locked mode.
        
        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.lock()
        print(resp.status)
        resp = sc.unlock()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.LOCK.value))
        return lockResponseMapper(json.loads(resp.data))
    
    def unlock(self) -> LockResponse:
        """
        Send a request to the server to unlock the "Ganzin Chronus" app.
    
        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        resp = sc.lock()
        print(resp.status)
        resp = sc.unlock()
        print(resp.status)
        ```
        """
        resp = self._http.request("POST", self._get_uri(Api.UNLOCK.value))
        return lockResponseMapper(json.loads(resp.data))

    def listen_to_update(self, callback) -> TaskRunningThread:
        """
        Listen to the server for updates.

        This method connects to the server using a WebSocket connection.
        The client will be updated in the following scenarios:
        - Start or stop recording
        - Lock or unlock the device
        - Turn on or off eye encoding
        - Change in mobile battery status
        - When another client connects to the server to receive status updates

        Arguments:
        ----------
            callback (Callable): The callback function to be called when an update is received.

        Returns:
        --------
            TaskRunningThread: The thread object that is listening to updates.

        Example:
        --------
        ```python
        def callback(data):
            print(data)

        sc = SyncClient(address, port)
        thread = sc.listen_to_update(callback)
        thread.start()
        ```
        """
        cancel_event = asyncio.Event()

        async def _listen_task():
            ws_uri = self._get_uri(Api.GET_STATUS.value, "ws")
            listener = UpdateListener(ws_uri, callback)
            await listener.begin_listen()
            await cancel_event.wait()
            await listener.end_listen()

        return TaskRunningThread(_listen_task, cancel_event)

    def create_streaming_thread(self, mode: StreamingMode,
                                on_start_callback = None) -> TaskRunningThread:
        """
        Creates a thread that runs the streaming task.

        Arguments:
        ----------
            mode (StreamingMode): Specifies the streaming mode to be used,
            enabling users to activate only the necessary streams.
            If GAZE_SCENE is specified, both gaze and scene camera streams will be activated.

            on_start_callback (Callable): A callback function that is called when the audio stream starts.
            This is useful for initializing the audio stream with the correct configuration.

        Returns:
        --------
            TaskRunningThread: The thread object that is running the streaming task.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        # Create a streaming thread that streams gaze and scene camera data.
        th = sc.create_streaming_thread(StreamingMode.GAZE_SCENE)
        th.start()

        try:
            while True:
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                buffer = frame_datum.get_buffer()
                gazes = sc.get_gazes_from_streaming(timeout=5.0)
                gaze = find_nearest_timestamp_match(frame_datum.get_timestamp_ms(), gazes)

                center = (int(gaze.combined.gaze_2d.x), int(gaze.combined.gaze_2d.y))
                radius = 30
                bgr_color = (255, 255, 0)
                thickness = 5
                cv2.circle(buffer, center, radius, bgr_color, thickness)

                cv2.imshow('Press "q" to exit', buffer)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            th.cancel()
            th.join()
            print('Stopped')
        ```
        """
        cancel_event = asyncio.Event()
           
        async def _recv_task():
            try:
                if mode & StreamingMode.GAZE:
                    gaze_url = self._rtsp_uri + Camera.GAZE.value
                    gaze_stream = GazeStreamCollector(gaze_url, weakref.ref(self._data))
                    gaze_stream.start()

                if mode & StreamingMode.SCENE:
                    scene_url = self._rtsp_uri + Camera.SCENE.value
                    scene_stream = SceneCameraVideoCollector(scene_url, weakref.ref(self._data))
                    scene_stream.start()

                if mode & StreamingMode.AUDIO:
                    scene_url = self._rtsp_uri + Camera.SCENE.value
                    audio_stream = SceneCameraAudioCollector(scene_url, weakref.ref(self._data), on_start_callback)
                    audio_stream.start()

                if mode & StreamingMode.AUDIO_VIDEO:
                    scene_url = self._rtsp_uri + Camera.SCENE.value
                    av_stream = SceneCameraAvCollector(scene_url, weakref.ref(self._data), on_start_callback)
                    av_stream.start()

                if mode & StreamingMode.EYES:
                    left_eye_url = self._rtsp_uri + Camera.LEFT_EYE.value
                    left_eye_stream = EyeCameraStreamCollector(left_eye_url, Camera.LEFT_EYE, weakref.ref(self._data))
                    left_eye_stream.start()

                    right_eye_url = self._rtsp_uri + Camera.RIGHT_EYE.value
                    right_eye_stream = EyeCameraStreamCollector(right_eye_url, Camera.RIGHT_EYE, weakref.ref(self._data))
                    right_eye_stream.start()

                if mode & StreamingMode.GAZE_EVENT:
                    gaze_event_url = self._rtsp_uri + Camera.GAZE_EVENT.value
                    gaze_event_stream = GazeEventStreamCollector(gaze_event_url, weakref.ref(self._data))
                    gaze_event_stream.start()

                await cancel_event.wait()
            except Exception as ex:
                print(ex)
        return TaskRunningThread(_recv_task, cancel_event)

    def get_gazes_from_streaming(self, timeout) -> list[GazeData]:
        """
        Retrieves the gaze data from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the gaze data.

        Returns:
        --------
            list[GazeData]: The list of gaze data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.GAZE_SCENE)
        th.start()

        try:
            while True:
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                buffer = frame_datum.get_buffer()
                # Retrieve the gaze data from the streaming thread.
                gazes = sc.get_gazes_from_streaming(timeout=5.0)
                gaze = find_nearest_timestamp_match(frame_datum.get_timestamp_ms(), gazes)

                center = (int(gaze.combined.gaze_2d.x), int(gaze.combined.gaze_2d.y))
                radius = 30
                bgr_color = (255, 255, 0)
                thickness = 5
                cv2.circle(buffer, center, radius, bgr_color, thickness)

                cv2.imshow('Press "q" to exit', buffer)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            th.cancel()
            th.join()
            print('Stopped')
        ```
        """
        gazes = self._data.pop_all_gazes()
        if gazes:
            return gazes
        else:
            return self._data.wait_for_gazes(timeout)

    def get_video_frames_from_streaming(self, timeout) -> list[VideoFrame]:
        """
        Retrieves the scene camera video frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the scene camera frames.

        Returns:
        --------
            VideoFrame: The frame data object.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.SCENE)
        th.start()

        try:
            while True:
                # Retrieve the scene camera frames from the streaming thread.
                frame_data = sc.get_scene_frames_from_streaming(timeout=5.0)
                frame_datum = frame_data[-1] # get the last frame
                cv2.imshow('Press "q" to quit', frame_datum.get_buffer())
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_scene_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_scene_frames(timeout)

    def get_audio_frames_from_streaming(self, timeout) -> list[AudioFrame]:
        """
        Retrieves the audio frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the audio frames.

        Returns:
        --------
            list[AudioFrame]: The list of audio frames.

        Example:
        --------
            To see how to use this method, refer to the sample code in the following file:
            File path: examples/audio_streaming.py
        """
        frames = self._data.pop_all_audio_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_audio_frames(timeout)
        
    def get_av_frames_from_streaming(self, timeout) -> List[Union[AudioFrame, VideoFrame]]:
        """
        Retrieves the audio and video frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the audio and video frames.

        Returns:
        --------
            list[Union[AudioFrame, VideoFrame]]: A list of frames, which can contain either audio or video frames.

        Example:
        --------
            To see how to use this method, refer to the sample code in the following file:
            File path: examples/synchronous/av_streaming.py
        """
        frames = self._data.pop_all_av_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_av_frames(timeout)

    def get_left_eye_frames_from_streaming(self, timeout=None) -> list[VideoFrame]:
        """
        Retrieves the left eye camera frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the left eye camera frames.

        Returns:
        --------
            list[VideoFrame]: The list of frame data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.EYES)
        th.start()

        try:
            while True:
                # Retrieve the left eye camera frames from the streaming thread.
                left_eye_data = sc.get_left_eye_frames_from_streaming(timeout=5.0)
                right_eye_data = sc.get_right_eye_frames_from_streaming()
                left_eye_datum = left_eye_data[0]
                right_eye_datum = find_nearest_timestamp_match(left_eye_datum.get_timestamp_ms(), right_eye_data)
                combined_img = numpy.hstack((left_eye_datum.get_buffer(), right_eye_datum.get_buffer()))
                
                cv2.imshow('Press "q" to quit', combined_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_left_eye_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_left_eye_frames(timeout)
        
    def get_right_eye_frames_from_streaming(self, timeout=None) -> list[VideoFrame]:
        """
        Retrieves the right eye camera frames from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the right eye camera frames.
        
        Returns:
        --------
            list[VideoFrame]: The list of frame data objects.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.EYES)
        th.start()

        try:
            while True:
                left_eye_data = sc.get_left_eye_frames_from_streaming(timeout=5.0)
                # Retrieve the right eye camera frames from the streaming thread.
                right_eye_data = sc.get_right_eye_frames_from_streaming()
                left_eye_datum = left_eye_data[0]
                right_eye_datum = find_nearest_timestamp_match(left_eye_datum.get_timestamp_ms(), right_eye_data)
                combined_img = numpy.hstack((left_eye_datum.get_buffer(), right_eye_datum.get_buffer()))
                
                cv2.imshow('Press "q" to quit', combined_img)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        frames = self._data.pop_all_right_eye_frames()
        if frames:
            return frames
        else:
            return self._data.wait_for_right_eye_frames(timeout)

    def get_gaze_event_from_streaming(self, timeout) -> List[RealtimeResult]:
        """
        Retrieves the gaze event data from the streaming thread.

        Arguments:
        ----------
            timeout: The maximum time to wait for the gaze event data.

        Returns:
        --------
            List[RealtimeResult]: The list of RealtimeResult objects, which contain gaze events.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        th = sc.create_streaming_thread(StreamingMode.GAZE_EVENT)
        th.start()

        try:
            while True:
                list = sc.get_gaze_event_from_streaming(timeout=5.0)
                for data in list:
                    print(data)
        except KeyboardInterrupt: # Press Ctrl-C to stop
            pass
        except Exception as ex:
            print(ex)
        finally:
            print('Stopped')

        th.cancel()
        th.join()
        ```
        """
        data = self._data.pop_all_gaze_event_data()
        if data:
            return data
        else:
            return self._data.wait_for_gaze_event_data(timeout)

    def run_time_sync(self, number_of_polls = 60) -> TimeSyncResult:
        """
        Run time synchronization with the server.

        Arguments:
        ----------
            number_of_polls: The number of time synchronization polls to perform.

        Returns:
        --------
            TimeSyncResult: The result of the time synchronization polls.

        Example:
        --------
        ```python
        sc = SyncClient(address, port)
        result = sc.run_time_sync(number_of_polls=80)
        print(f"Time Offset Mean: {result.time_offset.mean}")
        print(f"Round Trip Mean: {result.round_trip.mean}")
        ```
        """
        url = self._get_uri(Api.TIME_SYNC.value, "ws")
        time_sync = TimeSync(url)
        return asyncio.run(time_sync.polls_multiple_times(number_of_polls))
