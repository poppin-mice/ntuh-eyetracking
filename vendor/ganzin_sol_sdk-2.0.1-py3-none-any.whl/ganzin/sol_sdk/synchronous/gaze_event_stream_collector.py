import asyncio
import weakref
from ..streaming.gaze_event_stream import GazeEventStream

class GazeEventStreamCollector:
    """
    Class responsible for collecting gaze event data.
    """
    def __init__(self, url, data_mgr_ref: weakref.ReferenceType):
        """
        Initializes the collector with the stream URL and a weak reference to the data manager.

        Arguments:
        ----------
        - **url** : str
            The source URL for the gaze event stream.
        - **data_mgr_ref** : weakref.ReferenceType
            A weak reference to the data manager object, which is used to store the collected data.
        """
        self._url = url
        self._data_mgr = data_mgr_ref
        self._streaming_task = None

    def start(self):
        """
        Starts the collection of data.
        """
        self._streaming_task = asyncio.create_task(self._collect_gaze_event())

    async def _collect_gaze_event(self):
        self._data_mgr().clear_gaze_event_data_store()
        async with GazeEventStream(self._url) as streamer:
            async for item in streamer.get_data():
                self._data_mgr().add_gaze_event_data(item)
