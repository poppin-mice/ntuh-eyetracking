from http import HTTPStatus
import aiohttp
from ..api import Api
import json
from ..responses import (
    GetHostsResponse, LockResponse, PhoneStatusResponse, RecordResponse, TagResponse,
    CaptureResponse, VersionResponse, SceneCameraParamResponse,
    RequestSnapshotResponse, GetSnapshotImageResponse, GetSnapshotGazeResponse,
    SceneCamExposureConfigResponse, PostSceneCamExposureConfigResponse,
    getHostsResponseMapper, lockResponseMapper, recordResponseMapper, versionResponseMapper,
    captureResponseMapper, phoneStatusResponseMapper, sceneCameraParamResponseMapper,
    requestSnapshotResponseMapper, getSnapshotImageResponseMapper, getSnapshotGazeResponseMapper,
    sceneCamExposureConfigResponseMapper, postSceneCamExposureConfigResponseMapper,
    parse_json_to_object
)
from ..requests import AddTagRequest, GetSnapshotGazeRequest, PostSceneCamExposureConfigRequest
from ..utils import collect_update, _validate_sdk_version
from ..streaming.protocol import streaming_scheme
from ..streaming.gaze_stream import GazeStream
from ..streaming.video_stream import VideoStream
from ..streaming.audio_stream import AudioStream
from ..streaming.audio_frame import AudioFrame
from ..streaming.av_stream import AvStream
from ..streaming.gaze_event_stream import GazeEventStream
from ..time_sync import TimeSync, TimeSyncResult
from ..common_models import ApiStatus, Camera

class AsyncClient:
    """
    Asynchronous client for interacting with the server.
    """
    def __init__(self, address, port, rtsp_port=8086):
        """
        Initializes the AsyncClient instance with the specified address and ports.

        Arguments:
        ----------
        - **address** : str
            The IP address of the server.
        - **port** : int
            The port number of the server.
        - **rtsp_port** : int, optional
            The RTSP port number of the server (default is 8086).
        """
        self._uri = f"{address}:{port}"
        self._rtsp_uri = f"{address}:{rtsp_port}"
        self._session = aiohttp.ClientSession()

    async def _close(self):
        """
        Closes the client session.

        This method releases resources, particularly the HTTP client session,
        ensuring that all connections are properly closed and cleaned up.
        """
        await self._session.close()

    async def __aenter__(self) -> "AsyncClient":
        """
        Asynchronous context manager entry method.

        Retrieves the remote API version and validates it against the SDK version.
        Ensures compatibility before returning the AsyncClient instance.
        If the major version differs, raises an exception.

        Returns:
            AsyncClient: The current instance of the AsyncClient.
        """
        try:
            version_resp = await self.get_version()
            if version_resp.result is None:
                raise RuntimeError(
                    f'/api/version did not return a result: {version_resp.message!r}'
                )
            _validate_sdk_version(version_resp.result.remote_api_version)
        except BaseException:
            await self._close()
            raise
        return self

    async def __aexit__(self, exc_type, exc_value, traceback) -> "None":
        """
        Asynchronous context manager exit method.
        """
        await self._close()

    def _get_uri(self, api: Api, protocol="http"):
        return f"{protocol}://{self._uri}/api/{api}"
    
    async def get_version(self) -> VersionResponse:
        """
        Retrieves the SDK version that the server is expected to support.
        
        Returns:
        --------
            VersionResponse: The response object containing the SDK version.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_version()
            print(resp.result.remote_api_version)
        ```
        """
        async with self._session.request("GET", self._get_uri(Api.GET_VERSION.value)) as resp:
            return versionResponseMapper(json.loads(await resp.text()))

    async def get_hosts(self) -> GetHostsResponse:
        """
        Returns discovered host addresses from the mDNS discovery service.

        Returns:
        --------
            GetHostsResponse: The response object containing the list of discovered host IPs.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_hosts()
            print(resp.result.hosts)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.GET_HOSTS.value)) as resp:
            return getHostsResponseMapper(json.loads(await resp.text()))

    async def get_status(self) -> PhoneStatusResponse:
        """
        Retrieves the status of the server.

        Returns:
        --------
            PhoneStatusResponse: The response object containing the status information.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_status()
            print(resp.result.device_name)
        ```
        """
        async with self._session.request("GET", self._get_uri(Api.GET_STATUS.value)) as resp:
            return phoneStatusResponseMapper(json.loads(await resp.text()))

    async def get_scene_camera_param(self) -> SceneCameraParamResponse:
        """
        Retrieves the scene camera parameters.

        Returns:
        --------
            SceneCameraParamResponse: The response object containing the status, message, and optionally the scene camera parameters.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_scene_camera_param()
            print(resp.result.camera_param.intrinsic)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.GET_SCENE_CAMERA_PARAM.value)) as resp:
            if resp.status == HTTPStatus.OK:
                return sceneCameraParamResponseMapper(json.loads(await resp.text()))
            else:
                data = await resp.json()
                return SceneCameraParamResponse(ApiStatus(data["status"]), data.get("message"), None)

    async def begin_record(self) -> RecordResponse:
        """
        Send a request to the server to initiate recording.

        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.begin_record()
            print(resp.status)
            resp = await ac.end_record()
            print(resp.status)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.BEGIN_RECORD.value)) as resp:
            return recordResponseMapper(json.loads(await resp.text()))

    async def end_record(self) -> RecordResponse:
        """
        Send a request to the server to stop recording.
        
        Returns:
        --------
            RecordResponse: The response object containing the status of the recording.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.begin_record()
            print(resp.status)
            resp = await ac.end_record()
            print(resp.status)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.END_RECORD.value)) as resp:
            return recordResponseMapper(json.loads(await resp.text()))

    async def add_tag(self, request: AddTagRequest) -> TagResponse:
        """
        Send a request to the server to add the specified tag.

        Arguments:
        ----------
            request (AddTagRequest): The request object containing tag information.

        Returns:
        --------
            TagResponse: The response object.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            status_resp = await ac.get_status()
            elapsed_us = status_resp.result.recording_elapsed_time_us
            req = AddTagRequest('right moment', 'description', elapsed_us, TagColor.LightSeaGreen)
            resp = await ac.add_tag(req)
            print(f'Add tag result: {resp}')
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.ADD_TAG.value), json=request.to_json_body()) as resp:
            return parse_json_to_object(await resp.text(), TagResponse)

    async def capture(self) -> CaptureResponse:
        """
        Request server to capture frame and gaze.
        
        The response includes the frame image and the gaze data at that moment.

        Returns:
        --------
            CaptureResponse: The response object.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.capture()
            result = CaptureResult.from_raw(resp.result)
            print(f'timestamp_us = {result.timestamp_us}')
            print(f'gaze: x = {result.gaze_data.combined.gaze_2d.x}, y = {result.gaze_data.combined.gaze_2d.y}')
            with open("image_captured.jpg", "wb") as file:
                file.write(result.scene_image)
                print(f'Saved image to "{file.name}"')
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.CAPTURE.value)) as resp:
            return captureResponseMapper(json.loads(await resp.text()))

    async def snapshot(self) -> RequestSnapshotResponse:
        """
        Queue a snapshot on the next scene-camera frame.

        On success, `result.timestamp_us` is the presentation timestamp in
        microseconds. Pass it to `get_snapshot_image` and `get_snapshot_gaze`
        to retrieve the captured image and gaze data.

        Returns `status='FAILED'` with `message='Not previewing'` when the
        camera pipeline is not running.

        Returns:
        --------
            RequestSnapshotResponse: Contains `result.timestamp_us` on success.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.snapshot()
            if resp.status == 'SUCCESS':
                print(f'Snapshot queued at {resp.result.timestamp_us} us')
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.SNAPSHOT.value)) as resp:
            return requestSnapshotResponseMapper(json.loads(await resp.text()))

    async def get_snapshot_image(self, timestamp_us: int) -> GetSnapshotImageResponse:
        """
        Retrieve the snapshot image for a given presentation timestamp.

        Internally makes two HTTP calls:
          1. POST `/api/get_snapshot_image?timestamp_us=<value>` to get the
             relative file path from the device.
          2. GET `/api/file/<filepath>` to download the raw image bytes.

        The raw bytes are attached to `result.image_data` before the response
        is returned, so callers can write them to disk directly.

        Arguments:
        ----------
            timestamp_us (int): Presentation timestamp in microseconds, as
                returned by `snapshot()`.

        Returns:
        --------
            GetSnapshotImageResponse: Contains `result.filepath` and
                `result.image_data` (bytes) on success.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_snapshot_image(timestamp_us)
            if resp.status == 'SUCCESS':
                with open('snapshot.jpg', 'wb') as f:
                    f.write(resp.result.image_data)
                print(f'Saved to snapshot.jpg (from {resp.result.filepath})')
        ```
        """
        url = self._get_uri(Api.GET_SNAPSHOT_IMAGE.value)
        async with self._session.request("POST", url, params={'timestamp_us': timestamp_us}) as resp:
            meta = getSnapshotImageResponseMapper(json.loads(await resp.text()))

        if meta.status == 'SUCCESS' and meta.result and meta.result.filepath:
            file_url = f"{self._get_uri(Api.FILE.value)}/{meta.result.filepath}"
            async with self._session.request("GET", file_url) as file_resp:
                meta.result.image_data = await file_resp.read()

        return meta

    async def get_snapshot_gaze(self, request: GetSnapshotGazeRequest) -> GetSnapshotGazeResponse:
        """
        Retrieve the gaze sample closest to a snapshot timestamp.

        Arguments:
        ----------
            request (GetSnapshotGazeRequest): Contains `timestamp_us` in
                microseconds, matching the value returned by `snapshot()`.

        Returns:
        --------
            GetSnapshotGazeResponse: Contains `result.gaze` (a
                `SnapshotGazeData` instance) on success.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            from ganzin.sol_sdk.requests import GetSnapshotGazeRequest
            resp = await ac.get_snapshot_gaze(GetSnapshotGazeRequest(timestamp_us))
            if resp.status == 'SUCCESS' and resp.result.gaze:
                g = resp.result.gaze
                print(f'Gaze: ({g.gaze_pos_x:.1f}, {g.gaze_pos_y:.1f})  valid={g.gaze_valid}')
        ```
        """
        async with self._session.request(
            "POST", self._get_uri(Api.GET_SNAPSHOT_GAZE.value), json=request.to_json_body()
        ) as resp:
            return getSnapshotGazeResponseMapper(json.loads(await resp.text()))

    async def get_scene_cam_exposure_config(self) -> SceneCamExposureConfigResponse:
        """
        Retrieve the current scene-camera exposure configuration.

        Returns:
        --------
            SceneCamExposureConfigResponse: Contains `result.scene_cam_exposure_config`
                (a `SceneCamExposureConfig` instance) on success.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.get_scene_cam_exposure_config()
            if resp.status == 'SUCCESS':
                cfg = resp.result.scene_cam_exposure_config
                print(f'Mode: {cfg.mode}, Level: {cfg.fixed_mode_level}')
        ```
        """
        async with self._session.request(
            "POST", self._get_uri(Api.GET_SCENE_CAM_EXPOSURE_CONFIG.value)
        ) as resp:
            return sceneCamExposureConfigResponseMapper(json.loads(await resp.text()))

    async def post_scene_cam_exposure_config(
        self, request: PostSceneCamExposureConfigRequest
    ) -> PostSceneCamExposureConfigResponse:
        """
        Update the scene-camera exposure configuration.

        Only the fields set on `request.scene_cam_exposure_config` are sent;
        `None` fields are omitted so unrelated settings are left unchanged.

        Arguments:
        ----------
            request (PostSceneCamExposureConfigRequest): The new exposure
                configuration to apply.

        Returns:
        --------
            PostSceneCamExposureConfigResponse: Contains `status` and an optional
                `message` on failure.

        Example:
        --------
        ```python
        from ganzin.sol_sdk.common_models import SceneCamExposureConfig, SceneCamExposureMode
        from ganzin.sol_sdk.requests import PostSceneCamExposureConfigRequest

        async with AsyncClient(address, port) as ac:
            req = PostSceneCamExposureConfigRequest(
                SceneCamExposureConfig(mode=SceneCamExposureMode.FIXED, fixed_mode_level=0.7)
            )
            resp = await ac.post_scene_cam_exposure_config(req)
            if resp.status == 'SUCCESS':
                print('Config updated successfully')
        ```
        """
        async with self._session.request(
            "POST",
            self._get_uri(Api.POST_SCENE_CAM_EXPOSURE_CONFIG.value),
            json=request.to_json_body()
        ) as resp:
            return postSceneCamExposureConfigResponseMapper(json.loads(await resp.text()))

    async def lock(self) -> LockResponse:
        """
        Send a request to the server to switch the "Ganzin Chronus" app to locked mode.

        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.lock()
            print(resp.status)
            resp = await ac.unlock()
            print(resp.status)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.LOCK.value)) as resp:
            return lockResponseMapper(json.loads(await resp.text()))
        
    async def unlock(self) -> LockResponse:
        """
        Send a request to the server to unlock the "Ganzin Chronus" app.

        Returns:
        --------
            LockResponse: The response object.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            resp = await ac.lock()
            print(resp.status)
            resp = await ac.unlock()
            print(resp.status)
        ```
        """
        async with self._session.request("POST", self._get_uri(Api.UNLOCK.value)) as resp:
            return lockResponseMapper(json.loads(await resp.text()))

    def listen_to_update(self):
        """
        Listen to the server for updates.

        This method connects to the server using a WebSocket connection.
        The client will be updated in the following scenarios:
        - Start or stop recording
        - Lock or unlock the device
        - Turn on or off eye encoding
        - Change in mobile battery status
        - When another client connects to the server to receive status updates

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            print("While we are listening to updates from server, you can press Ctrl-C to exit.")
            async for update in ac.listen_to_update():
            print(update) 
        ```
        """
        ws_uri = self._get_uri(Api.GET_STATUS.value, "ws")
        return collect_update(ws_uri)

    def _gaze_stream(self, *args, **kwargs):
        """
        Connect to the gaze stream.
        """
        url = f"{streaming_scheme}://{self._rtsp_uri}/?camera=gaze"
        return GazeStream(url, *args, **kwargs)

    def _video_stream(self, target: Camera, *args, **kwargs):
        """
        Connect to the video stream.
        """
        url = f"{streaming_scheme}://{self._rtsp_uri}/?camera={target.value}"
        return VideoStream(url, *args, **kwargs)

    def _audio_stream(self, target: Camera, *args, **kwargs):
        """
        Connect to the audio stream.
        """
        url = f"{streaming_scheme}://{self._rtsp_uri}/?camera={target.value}"
        return AudioStream(url, *args, **kwargs)

    def _av_stream(self, target: Camera, *args, **kwargs):
        """
        Connect to the audio-video stream.
        """
        url = f"{streaming_scheme}://{self._rtsp_uri}/?camera={target.value}"        
        return AvStream(url, *args, **kwargs)

    def _gaze_event_stream(self, *args, **kwargs):
        """
        Connect to the gaze event stream.
        """
        url = f"{streaming_scheme}://{self._rtsp_uri}/?camera=gaze_event"
        return GazeEventStream(url, *args, **kwargs)

    async def run_time_sync(self, number_of_polls = 60) -> TimeSyncResult:
        """
        Run time synchronization with the server.

        Returns:
        --------
            TimeSyncResult: The result of the time synchronization polls.

        Example:
        --------
        ```python
        async with AsyncClient(address, port) as ac:
            result = await ac.run_time_sync(number_of_polls=80)
            print(f"Time Offset Mean: {result.time_offset.mean}")
            print(f"Round Trip Mean: {result.round_trip.mean}")
        ```
        """
        url = self._get_uri(Api.TIME_SYNC.value, 'ws')
        time_sync = TimeSync(url)
        return await time_sync.polls_multiple_times(number_of_polls)

async def recv_gaze(ac: AsyncClient, *args, **kwargs):
    """
    Asynchronously receives gaze data from a gaze stream.

    This function connects to a gaze stream using the provided AsyncClient instance,
    and yields gaze data as it is received from the stream.

    Arguments:
    ----------
        - ac (AsyncClient): An instance of AsyncClient to connect to the gaze stream.
        - *args: Variable length argument list to pass to the gaze stream.
        - **kwargs: Arbitrary keyword arguments to pass to the gaze stream.

    Yields:
    -------
        GazeData: Parsed gaze data received from the stream.

    Example:
    ```python
    async for gaze_data in recv_gaze(ac):
        process_gaze(gaze_data)
    ```
    """
    async with ac._gaze_stream(*args, **kwargs) as stream:
        async for data in stream.get_data():
            yield data

async def recv_video(ac: AsyncClient, target: Camera, *args, **kwargs):
    """
    Asynchronously receives video frames from a video stream.

    This function connects to a video stream using the provided AsyncClient instance
    and the specified target camera, and yields video frames as they are received from the stream.

    Arguments:
    ----------
        - ac (AsyncClient): An instance of AsyncClient to connect to the video stream.
        - target (Camera): The target camera to receive video from. For example, Camera.SCENE or Camera.LEFT_EYE.
        - *args: Variable length argument list to pass to the video stream.
        - **kwargs: Arbitrary keyword arguments to pass to the video stream.

    Yields:
    -------
        FrameData: Parsed video frame data received from the stream.

    Example:
    ```python
    async for frame in recv_video(ac, target):  
        process_frame(frame)
    ```
    """
    async with ac._video_stream(target, *args, **kwargs) as stream:
        async for frame in stream.get_data():
            yield frame

async def recv_audio(ac: AsyncClient, target: Camera, config_callback, *args, **kwargs):
    """
    Asynchronously receives audio data from an audio stream.

    This function connects to an audio stream using the provided AsyncClient
    instance and the specified target camera, and yields audio frames as they
    are received from the stream.

    Arguments:
    ----------
        - ac (AsyncClient): An instance of AsyncClient to connect to the audio stream.
        - target (Camera): The target camera to receive audio from. For example, Camera.LEFT_EYE.
        - config_callback: A callback function to handle the audio configuration.
        - *args: Variable length argument list to pass to the audio stream.
        - **kwargs: Arbitrary keyword arguments to pass to the audio stream.

    Yields:
    -------
        AudioFrame: Audio frame data received from the stream.

    Example:
    --------
        To see how to use this method, refer to the sample code in the following file:
        File path: examples/audio_streaming.py
    """
    first_time = True
    async with ac._audio_stream(target, *args, **kwargs) as stream:
        async for frame in stream.get_data():
            if first_time:
                first_time = False
                config_callback(stream.audio_config)
            yield frame

async def recv_av(ac: AsyncClient, target: Camera, config_callback, *args, **kwargs):
    """
    Asynchronously receives audio and video data from an audio-video stream.

    This function connects to an audio-video stream using the provided AsyncClient
    instance and the specified target camera, and yields audio and video frames
    as they are received from the stream.

    Arguments:
    ----------
        - ac (AsyncClient): An instance of AsyncClient to connect to the audio-video stream.
        - target (Camera): The target camera to receive audio and video from. For example, Camera.LEFT_EYE.
        - config_callback: A callback function to handle the audio configuration.
        - *args: Variable length argument list to pass to the audio-video stream.
        - **kwargs: Arbitrary keyword arguments to pass to the audio-video stream.
        
    Yields:
    -------
        AudioFrame or FrameData: Audio frame or video frame data received from the stream.

    Example:
    --------
        To see how to use this method, refer to the sample code in the following file:
        File path: examples/av_streaming.py
    """
    is_audio_initialized = False
    async with ac._av_stream(target, *args, **kwargs) as stream:
        async for frame in stream.get_data():
            if not is_audio_initialized and isinstance(frame, AudioFrame):
                config_callback(stream.audio_config)
                is_audio_initialized = True
            yield frame


async def recv_gaze_event(ac: AsyncClient, *args, **kwargs):
    """
    Asynchronously receives real-time data from a gaze event stream.

    This generator function establishes a connection to the gaze event stream using the
    provided AsyncClient and yields raw result data structures as they arrive
    from the stream.

    Arguments:
    ----------
        - ac (AsyncClient): An instance of AsyncClient to connect to the stream.
        - *args: Variable length argument list to pass to the gaze event stream initialization.
        - **kwargs: Arbitrary keyword arguments to pass to the gaze event stream initialization.

    Yields:
    -------
        RealtimeResult: Encapsulates a snapshot of gaze event data.

    Example:
    --------
        To see how to use this method, refer to the sample code in the following file:
        File path: examples/asynchronous/gaze_event_streaming.py
    """
    async with ac._gaze_event_stream(*args, **kwargs) as stream:
        async for data in stream.get_data():
            yield data