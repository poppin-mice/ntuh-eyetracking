from dataclasses import dataclass
import enum
from typing import Optional

from .common_models import SceneCamExposureConfig

class TagColor(enum.Enum):
    """
    Enum class for predefined tag colors.
    """
    Gold = 0
    """
    Represents the color Gold
    """
    LightSeaGreen = 1
    """
    Represents the color LightSeaGreen
    """
    SkyBlue = 2
    """
    Represents the color SkyBlue
    """
    RoyalBlue = 3
    """
    Represents the color RoyalBlue
    """
    Tomato = 4
    """
    Represents the color Tomato
    """
    Pink = 5
    """
    Represents the color Pink
    """
    Purple = 6
    """
    Represents the color Purple
    """
    DarkGray = 7
    """
    Represents the color DarkGray
    """
    Black = 8
    """
    Represents the color Black"""
    White = 9
    """
    Represents the color White
    """

@dataclass
class AddTagRequest:
    """
    Dataclass representing a request to add a tag with a specified brush and timestamp.
    """
    name: str
    """ The name of the tag. """
    description: str
    """ The description of the tag. """
    brush: str
    """ The brush color of the tag. """
    record_elapsed_time_us: Optional[int] = None
    """ Elapsed recording time in microseconds at which to place the tag. Optional; server uses 'now' when absent. """

    def __init__(self, name, desc, record_elapsed_time_us, color: TagColor):
        """ Initializes the AddTagRequest instance with the specified values. """
        self.name = name
        self.description = desc
        self.record_elapsed_time_us = round(record_elapsed_time_us) if record_elapsed_time_us is not None else None
        self.brush = Brush.get(color)

    def to_json_body(self) -> dict:
        """
        Returns the dataclass as a dict suitable for the request body, with
        `None` values dropped so the server sees only the fields the caller
        explicitly set.
        """
        return {k: v for k, v in vars(self).items() if v is not None}

@dataclass
class GetSnapshotGazeRequest:
    """
    Dataclass representing a request to retrieve the gaze sample closest
    to a snapshot timestamp.
    """
    timestamp_us: int
    """ The snapshot presentation timestamp in microseconds, as returned by `/api/snapshot`. """

    def to_json_body(self) -> dict:
        """
        Returns the request as a dict suitable for the JSON body.
        """
        return {'timestamp_us': self.timestamp_us}


@dataclass
class PostSceneCamExposureConfigRequest:
    """
    Dataclass representing a request to update the scene-camera exposure configuration.

    All fields inside `scene_cam_exposure_config` are optional, so only the
    fields that are set will be sent to the server.

    Example:
    ```python
    from ganzin.sol_sdk.common_models import SceneCamExposureConfig, SceneCamExposureMode
    from ganzin.sol_sdk.requests import PostSceneCamExposureConfigRequest

    req = PostSceneCamExposureConfigRequest(
        SceneCamExposureConfig(mode=SceneCamExposureMode.FIXED, fixed_mode_level=0.7)
    )
    ```
    """
    scene_cam_exposure_config: SceneCamExposureConfig
    """ The exposure configuration fields to apply. """

    def to_json_body(self) -> dict:
        """
        Returns the request as a dict suitable for the JSON body.
        Fields set to None in the config are omitted.
        """
        config = {k: v for k, v in vars(self.scene_cam_exposure_config).items() if v is not None}
        return {'scene_cam_exposure_config': config}


class Brush:
    """
    Class representing Brush color of predefined tag colors.

    Examples:
    ```python
    >>> color = Brush.get(TagColor.Gold)
    >>> print(color)
    '#FFC700'
    ```
    """
    preset = [
              '#FFC700',
              '#00A1A7',
              '#62D6FB',
              '#2E6CF6',
              '#E04444',
              '#FF7CBB',
              '#784587',
              '#8E8C8C',
              '#000000',
              '#FFFFFF'
            ]
    """
    Preset colors for the brush.
    """
    
    @classmethod
    def get(cls, color: TagColor):
        """
        Returns the text representation of the brush color for the specified TagColor.
        """
        return cls.preset[color.value]
