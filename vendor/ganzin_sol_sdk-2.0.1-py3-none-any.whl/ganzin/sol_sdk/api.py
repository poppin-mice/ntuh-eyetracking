from enum import Enum

class Api(Enum):
    """
    @private
    Enum class representing various API endpoints.
    """

    GET_VERSION = "version"
    """
    Endpoint for getting the version information.
    """

    GET_STATUS = "status"
    """
    Endpoint for getting the status information.
    """

    GET_SCENE_CAMERA_PARAM = "scene_camera_param"
    """
    Endpoint for getting the scene camera parameters.
    """

    BEGIN_RECORD = "recording_start"
    """
    Endpoint for starting a recording.
    """

    END_RECORD = "recording_stop"
    """
    Endpoint for stopping a recording.
    """

    ADD_TAG = "tag"
    """
    Endpoint for adding a tag.
    """

    CAPTURE = "capture_scene_with_gaze"
    """
    Endpoint for capturing a video stream frame from the scene camera with gaze data.
    """

    TIME_SYNC = "time_sync"
    """
    Endpoint for synchronizing time.
    """

    LOCK = "lock"
    """
    Endpoint for locking the device.
    """

    UNLOCK = "unlock"
    """
    Endpoint for unlocking the device.
    """

    SNAPSHOT = "snapshot"
    """
    Endpoint for queuing a snapshot on the next scene-camera frame.
    """

    GET_SNAPSHOT_IMAGE = "get_snapshot_image"
    """
    Endpoint for retrieving the file path of a snapshot image by timestamp.
    """

    GET_SNAPSHOT_GAZE = "get_snapshot_gaze"
    """
    Endpoint for retrieving the gaze sample closest to a snapshot timestamp.
    """

    FILE = "file"
    """
    Endpoint for downloading a file by its relative path.
    Successful responses are raw binary, not the standard JSON envelope.
    """

    GET_SCENE_CAM_EXPOSURE_CONFIG = "scene_cam_exposure_config"
    """
    Endpoint for retrieving the current scene-camera exposure configuration.
    """

    POST_SCENE_CAM_EXPOSURE_CONFIG = "post_scene_cam_exposure_config"
    """
    Endpoint for updating the scene-camera exposure configuration.
    """

    GET_HOSTS = "hosts"
    """
    Endpoint for retrieving discovered host addresses from mDNS discovery.
    """
