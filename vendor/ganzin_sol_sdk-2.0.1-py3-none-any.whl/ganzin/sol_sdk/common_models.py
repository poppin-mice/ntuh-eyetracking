from dataclasses import dataclass
from enum import StrEnum
from typing import Optional

class ApiStatus(StrEnum):
    SUCCESS = "SUCCESS",
    FAILED = "FAILED"

class Camera(StrEnum):
    """
    Enum class representing different camera types.
    """

    GAZE = "gaze"
    """
    Represents the gaze camera.
    """

    SCENE = "scene"
    """
    Represents the scene camera.
    """
    
    LEFT_EYE = "left_eye"
    """
    Represents the left eye camera.
    """

    RIGHT_EYE = "right_eye"
    """
    Represents the right eye camera.
    """

    GAZE_EVENT = "gaze_event"
    """
    Represents the stream for gaze events.
    """

class SceneCamExposureMode(StrEnum):
    """
    Exposure control mode for the scene camera.
    """
    AUTO = "AUTO"
    """
    Auto exposure driven by the on-device software controller using
    smoothed center-region luma metering.
    """
    FIXED = "FIXED"
    """
    Fixed exposure derived from the `fixed_mode_level` field in `SceneCamExposureConfig`.
    """
    GAZE = "GAZE"
    """
    Gaze-driven auto exposure using smoothed gaze-region luma metering.
    """


@dataclass
class SceneCamExposureConfig:
    """
    Scene-camera exposure configuration.

    All fields are optional so clients may update any subset independently.
    `fixed_mode_level` is only meaningful when `mode` is `FIXED`; for other modes the
    on-device controller adjusts exposure automatically.
    `auto_mode_smoothing` and `gaze_mode_smoothing` tune the EMA smoothing
    factor in `[0, 1]` used by `AUTO` and `GAZE` modes respectively;
    `0` disables smoothing.

    Example:
    ```python
    from ganzin.sol_sdk.common_models import SceneCamExposureConfig, SceneCamExposureMode

    # Switch to auto mode
    config = SceneCamExposureConfig(mode=SceneCamExposureMode.AUTO)

    # Fixed exposure at 70 %
    config = SceneCamExposureConfig(mode=SceneCamExposureMode.FIXED, fixed_mode_level=0.7)
    ```
    """
    mode: Optional[str] = None
    """
    Exposure control mode. Use `SceneCamExposureMode` values:
    `AUTO`, `FIXED`, `GAZE`.
    """
    fixed_mode_level: Optional[float] = None
    """
    Exposure level ratio in `[0, 1]`. Only effective when `mode` is `FIXED`.
    """
    auto_mode_smoothing: Optional[float] = None
    """
    EMA time constant in `[0, 1]` for `AUTO` mode luma smoothing.
    Larger values smooth more / respond slower; `0` disables smoothing.
    """
    gaze_mode_smoothing: Optional[float] = None
    """
    EMA time constant in `[0, 1]` for `GAZE` mode luma smoothing.
    Larger values smooth more / respond slower; `0` disables smoothing.
    """


@dataclass
class SemanticVersion:
    """
    Dataclass representing a semantic version.
    """

    major: int
    """
    The major version number.
    """

    minor: int
    """
    The minor version number.
    """

    patch: int
    """
    The patch version number.
    """

    def __repr__(self):
        return f"{self.major}.{self.minor}.{self.patch}"